<?php get_header();?>
<?php
$baghdad_news_header_slider_category  = esc_attr( get_theme_mod( 'baghdad_news_header_slider_category', 'all' ) );
$baghdad_news_header_slider_max_posts = esc_attr( get_theme_mod( 'baghdad_news_header_slider_max_posts', '6' ) );
$baghdad_news5_fullwidth      = get_theme_mod( 'baghdad_news5_fullwidth', false );
$baghdad_news_header_slider_disable   = (bool) get_theme_mod( 'baghdad_news_header_slider_disable', false );
$baghdad_news_header_slider_random    = (bool) get_theme_mod( 'baghdad_news_header_slider_random', false );
$baghdad_news5_disable        = (bool) get_theme_mod( 'baghdad_news5_disable', false );
ben_setPostViews(get_the_ID());
// 
$Advertisement_before_archive_url  =  get_theme_mod( 'baghdad_news_Advertisement_before_archive_url' );
$Advertisement_before_archive_img  =  get_theme_mod( 'baghdad_news_Advertisement_before_archive_img' );
$Advertisement_before_archive_code =  get_theme_mod( 'baghdad_news_Advertisement_before_archive_Code' );
?>




     <div class="div-container div-division"> <!------ok----->
     <style>
@media (max-width: 500px){
    .header-cover{
        height:50px;
        margin-bottom:10px;
    }
    .header-body {
        position: fixed;
        top: 0;
        height: 42px;
        padding-bottom: 10px;
        padding: 2px 2%;
        transition: .1s;
        z-index: 99;
    }
    .header-body .social-icons-top {
       opacity: 0;
       visibility: hidden;
    }
}


</style>
        <!-- news ticker start -->
        <div class="news-ticker-bar">
        
           <?php
			    $archive_content_classes = apply_filters( 'baghdad_news_archive_content_classes', array( 'baghdad_news-content-left', 'col-md-9' ) );
		   ?>

          <?php                
	        /* ---------Section 5--------- */
	        if ( ! $baghdad_news5_fullwidth && ! $baghdad_news5_disable ) {
	    	    baghdad_news_display_section( 5 );
	        }
	       ?>
        </div>
        <!-- news ticker end   -->
         <!----div.post-start--------->
        <div class="hassan">
        <div id="side" class="post-side content sidebar-wrapper">
        <?php if ( ! empty( $Advertisement_before_archive_code ) ) { 
               echo  '<div class="Advertisement-article-footer adds">'.$Advertisement_before_archive_code.'</div>'; 
           
            }
            

            else {
                if ( ! empty( $Advertisement_before_archive_img ) ) {
                    echo '<div class="Advertisement-article-footer adds">
                              <a href="'.$Advertisement_before_archive_url.'" target="_blank">
                                  <img src="'.$Advertisement_before_archive_img.'" />
                              </a>
                          </div>';
                }
            }
            
            

        ?>
            <div class="div-content ">

            <?php if (have_posts()):?>
                <?php while (have_posts()):?>
                    <?php the_post();
                    $category      = get_the_category();
                    ?>
                    <!--------post single box code start--------->
                    
			        <section class="bost-box-single">

                        <div itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
                            <div class="post-header">
                                <div class="breadcrumbs">
                                    <span typeof="v:Breadcrumb">
                                        <a class="bhome" href="<?php echo get_home_url(); ?>" property="v:title" rel="v:url">
                                            <i class="fa fa-home" aria-hidden="true"></i>
                                            <?php esc_html_e( 'Home', 'baghdad-news' ); ?>
                                        </a>
                                    </span><i class="fa">/</i>
                                    <span >
                                        <a href="<?php echo esc_url( get_category_link( $category[0]->cat_ID ) ); ?>"
           								title="<?php esc_html_e( 'Category', 'baghdad-news' ); ?> <?php echo esc_attr( $category[0]->cat_name ); ?>">
           								<?php echo esc_attr( $category[0]->cat_name ); ?>
                                       </a>
                                    </span> 
                                        <i class="fa">/</i>
                                    <span>
                                        .....
                                    </span>
                                </div>

                                <div class="post-head">
                                     <h1 class="post-title entry-title" itemprop="name headline">
                                       <?php the_title();?>
                                     </h1>
                                </div>

                                <div class="post-meta">
                                    <span class="auther-igm auther-meta">
                                        <?php echo get_avatar( $comment, 32 ); ?>
                                    </span>

                                    <span class="auther-name auther-meta meta-span" itemprop="author" itemscope="itemscope">
                                        <?php the_author_posts_link();?>
                                    </span>

                                    <span class="meta-span meta-times">
                                        <i class="fa fa-clock-o"></i>
                                        <time datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished"><?php echo get_the_date(); ?></time>
                                    </span>

                                    <div class="meta-div">
                                        <span class="meta-span meta-comment">
                                            <a href="#comments">
                                                <i class="fa fa-comments" style="margin: 0 3px;"></i>
                                                <?php comments_number( '0', '1', '%' ); ?>
                                            </a>
                                        </span>
                                        <span class="meta-span meta-views">
                                                <i class="fa fa-eye" style="margin: 0 3px;"></i>
                                                <?php echo ben_getPostViews(get_the_ID()); ?>
                                        </span>
                                    </div>

                                </div>

                                <!-- 2 -->

                                
                            </div>
                            
                            <article class="item-article">
                                <div class="post-body entry-content" id="post-body-1437166064562756638" itemprop="articleBody">
                                    <div dir="rtl" style="text-align: right; padding-bottom: 10px;" trbidi="on">
                                        <div dir="rtl" class="post-sigle-img" trbidi="on">
                                            <div class="separator" style="clear: both; text-align: center; text-align: right;  overflow: hidden;">
                                               
                                                <?php the_post_thumbnail( 'full');?>
                                            </div>
                                        </div>
					        		</div>
							
						        	<div class="bost-box-text-singl entry">
						        		<?php the_content();?>
						        	</div>
                                </div>
                            </article>

                            <div class="post-tags">
                                <?php the_tags( '<li class="tag-item" style="color:var(--text-link-colo);">
                                                    <span class="fa fa-tags" aria-hidden="true"></span>
                                                    '.esc_html__( 'Tags', 'baghdad-news' ).'
                                                </li>
                                <li class="tag-item">', '</li><li class="tag-item">', '</li>' ); ?>
                            </div>

                            <div class="post-footer">
                                <div class="share-box">
                                    <style>
                                        @media  (max-width: 1100px) and (min-width: 500px){
                                            .footer-box {
                                                padding-bottom: 40px;
                                            }
                                        }
                                    </style>
                                    <h8 class="share-title"><?php _e( 'Share the topic on:', 'baghdad-news' ); ?></h8>
                                    <div class="share-art  icons-only">
                                        <!-- facebook -->
                                        <a class="fac-art twi-artfacebook-share-btn" 
                                        href="https://www.facebook.com/sharer?u=<?php the_permalink();?>&t=<?php the_title();?>" 
                                        onclick="window.open(this.href, 'windowName', 'width=600, height=400, right=24, top=24, scrollbars, resizable'); 
                                        return false;" rel="nofollow" target="_blank">
                                        
                                            <i class="fa fa-facebook"></i>
                                            <span class="resp_del"> <?php _e( 'Facebook', 'baghdad-news' ); ?></span>
                                        </a>

                                        <!-- ---twitter-- -->
                                         
                                        
                                        <a class="twi-art "  href="https://twitter.com/intent/tweet?text=<?php the_permalink();?>&t=<?php the_title();?>"  
                                        onclick="window.open(this.href, 'windowName', 'width=600, height=400, right=24, top=24, scrollbars, resizable'); 
                                        return false;" rel="nofollow" target="_blank">
                                            <i class="fa fa-twitter"></i>
                                            <span class="resp_del2"> <?php _e( 'Twitter', 'baghdad-news' ); ?></span>
                                        </a>


                                        <!-- --whatsapp--- -->
                                        <a class="whats-art" href="https://wa.me/?text=<?php the_permalink();?>&t=<?php the_title();?>" 
                                        onclick="window.open(this.href, 'windowName', 'width=600, height=400, right=24, top=24, scrollbars, resizable'); 
                                        return false;" rel="nofollow" target="_blank">

                                            <i class="fa fa-whatsapp"></i>
                                            <span class="resp_del3"> <?php _e( 'Whatsapp', 'baghdad-news' ); ?></span>
                                        </a>
                                        
                                        <!-- --pinterest--- -->
                                        
                                        <a class="pin-art" href="http://pinterest.com/pin/create/button/?url=<?php the_permalink();?>&t=<?php the_title();?>" 
                                        onclick="window.open(this.href, 'windowName', 'width=600, height=400, right=24, top=24, scrollbars, resizable'); 
                                        return false;" rel="nofollow" target="_blank">

                                            <i class="fa fa-pinterest"></i>
                                            <span class="resp_del4"> <?php _e( 'Pinterest', 'baghdad-news' ); ?></span>
                                        </a>


                                        <!--  linkedin -->

                                        <a class="lin-art" href="http://www.linkedin.com/shareArticle?url=<?php the_permalink();?>&t=<?php the_title();?>" 
                                        onclick="window.open(this.href, 'windowName', 'width=600, height=400, right=24, top=24, scrollbars, resizable'); 
                                        return false;" rel="nofollow" target="_blank">

                                            <i class="fa fa-linkedin-square"></i>
                                            <span class="resp_del5"><?php _e( 'Linkedin', 'baghdad-news' ); ?></span>
                                        </a>
                                        
                                        <!-- ---email-- -->

                                        <a class="mail-art" href="mailto:?subject=<?php the_permalink();?>&t=<?php the_title();?>" 
                                        onclick="window.open(this.href, 'windowName', 'width=600, height=400, right=24, top=24, scrollbars, resizable'); 
                                        return false;" rel="nofollow" target="_blank">

                                           <i class="fa fa-envelope"></i>
                                        </a>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    

                    <!--------post single box code end --------->
                <?php endwhile; ?>
            <?php else: ?>
                <div class="main-content tie-col-md-8 tie-col-xs-12" role="main">

		
                    <header class="entry-header-outer container-wrapper">
                    	<h1 class="page-title">لم يتم العثور على نتائج</h1>
                    </header><!-- .entry-header-outer /-->

                    <div class="mag-box not-found">
                    	<div class="container-wrapper">
                    
                    		
                    		<h5>يبدوا أننا لم ’ نستطيع أن نجد ما ’ تبحث عنه. من الممكن أن البحث يفيدك.</h5>
                            <form role="search" method="get" id="searchform" class="search-form" action="<?php echo get_home_url(); ?>">                    
                    		    <label>
                                    <input class="search-field"type="text" placeholder="search form"  name="s" di="s" id="search" value="<?php the_search_query(); ?>">
                                </label>
                                
                                <input class="search-submit" type="submit" id="searchsubmit" value="بحث">
                        	</form>
                    		
                    	</div><!-- .container-wrapper /-->
                    </div><!-- .mag-box /-->

	            </div>
            <?php endif;?>


            
            <?php if ( get_theme_mod( 'baghdad_news_related_posts_activate', 0 ) == 1 )
               get_template_part( 'inc/related-posts' );
            ?>
            

            <section class="bost-box-single">
                <?php
                    // If comments are open or we have at least one comment, load up the comment template.
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                ?>
            </section>



            </div>
        </div>
        <!----div-end..--------->

<?php get_sidebar();?>
<?php get_footer();?><div>
