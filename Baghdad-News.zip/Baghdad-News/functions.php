<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

// get file's

// widget files
require get_template_directory() . '/inc/widgets.php';
// customize file
require get_template_directory() . '/inc/customizer/customizer.php';
// banners-function file
require get_template_directory() . '/template-parts/banners-function.php';
// functions file
require get_template_directory() . '/functions/css-js-connected.php';
// excerpt file
require get_template_directory() . '/functions/excerpt.php';
// search file
require get_template_directory() . '/functions/search.php';
// logo file
require get_template_directory() . '/functions/wp-logo.php';
// widget file
require get_template_directory() . '/functions/widget.php';
// color output file
require get_template_directory() . '/functions/color-output.php';
// back img file
require get_template_directory() . '/functions/back-img.php';
// body class file
require get_template_directory() . '/functions/body-class.php';
// post-support
require get_template_directory() . '/functions/post-support.php';
// Display the related-posts
require get_template_directory() . '/functions/related-posts.php';
// all-functions
require get_template_directory() . '/functions/all-functions.php';





//Initialize the update checker.
// require 'theme-updates/theme-update-checker.php';
// $example_update_checker = new ThemeUpdateChecker(
//     'example-theme',
//     'http://example.com/example-theme/info.json'
// );


require 'path/to/plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'http://example.com/path/to/details.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'unique-plugin-or-theme-slug'
);


?>