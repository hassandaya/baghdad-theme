<?php get_header();?>


<div class="div-container div-division author-container"> <!------ok----->
<style>
@media (max-width: 500px){
    .header-cover{
        height:50px;
        margin-bottom:10px;
    }
    .header-body {
        position: fixed;
        top: 0;
        height: 42px;
        padding-bottom: 10px;
        padding: 2px 2%;
        transition: .1s;
        z-index: 99;
    }
    .header-body .social-icons-top {
       opacity: 0;
       visibility: hidden;
    }
}
</style>
    <!-- news ticker start -->
    <div class="news-ticker-bar">
        <?php              
	    /* ---------Section 5--------- */
	        if ( ! $baghdad_news5_fullwidth && ! $baghdad_news5_disable ) {
	    	  baghdad_news_display_section( 5 );
	    	}
	    ?>
    </div>
    <!-- news ticker end   -->

    <!----div.post-start--------->
    <div class="hassan">
    <div id="side" class="post-side content sidebar-wrapper">
        <div class="div-content ">
        
            
            <?php
                // back img file
                require get_template_directory() . '/inc/author-box.php';
            ?>


            <?php if (have_posts()):?><div class="box-style">
                <div class="time-line-yare"><?php  echo get_the_date( ' Y' ); ?></div>
                <?php while (have_posts()):?>
                    <?php the_post();?>
                    
                    <!--------post box code start--------->
    
                    <section  class="bost-box"> 
                        <div class="time-line-moon">
                           <?php echo get_the_date( 'j , F' ); ?>
                        </div>
                        <!------seaction-img.start-------->
                        <div class="bost-box-img ">
                            
                            <!-- post support start-->
                           <a href="<?php the_permalink()?>">
                            <?php if(has_post_thumbnail()):?>
                                     <?php echo covernews_post_format($post->ID); ?>
                                     <?php the_post_thumbnail( 'large', true );?>

                            <?php else:?>
                                
                                <?php echo '<div class="no-featuer-img"><img src="' . esc_url( get_theme_mod('dosislite_nav_logo_url') ) . '" /></div>'; ?>
                                
                            <?php endif?>
                            </a>
                        </div>
                        <!------seaction-img.end..-------->

                        

                        <!------seaction-header.start----->
                        <header class="bost-box-header " >
                            <h3>
                                <a href="<?php the_permalink()?>">
                                    <?php the_title();?>
                                </a>
                            </h3>    
                        </header>
                        <!------seaction-header.end------->
               


                        <!----div-footer.start--------->
                        <footer class="bost-box-footer ">
                            <span id="posts-box-user-icon" class="Coding-icon l">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </span>
    
    
                            <span id="posts-box-user-text" class="posts-box-footer-data ">
                               <?php the_author_posts_link();?>
                               
                            </span>
                            <span id="posts-box-time-icon" class="Coding-icon " title="وقت نشر المقالة">
                                <i class="fa fa-clock-o" aria-hidden="true"></i>
                            </span>
                       
                            <span id="posts-box-time-text" class="posts-box-footer-data " title="وقت نشر المقالة">
                                <time datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished"><?php echo get_the_date(); ?></time>
                            </span>
                        </footer>
                        <!----div-footer.end..--------->

                        <!----div-article.start-------->
                        <article class="bost-box-text ">
                                <?php the_excerpt();?>
                        </article>
                        <!----div-article.end..-------->
                    </section>

                    <!--------post box code end --------->
                <?php endwhile; ?>
               
                <?php else: ?>
                    <style>
                        .entry-header-outer{
                            margin-bottom:0px;
                        }

                        .box-style{
                            display: block;
                            padding: 0;
                        }
                    </style>
		
                    <header class="entry-header-outer container-wrapper">
                    	<h1 class="page-title">لم يتم العثور على نتائج</h1>
                    </header><!-- .entry-header-outer /-->

                    <div class="mag-box not-found">
                    	<div class="container-wrapper">
                    
                    		
                    		<h5>يبدوا أننا لم ’ نستطيع أن نجد المحتوى ’الذي تبحث عنه. من الممكن أن البحث يفيدك.</h5>

                            <form role="search" method="get" id="searchform" class="search-form" action="<?php echo get_home_url(); ?>">                    
                    		    <label>
                                    <input class="search-field"type="text" placeholder="search form"  name="s" di="s" id="search" value="<?php the_search_query(); ?>">
                                </label>
                                
                                <input class="search-submit" type="submit" id="searchsubmit" value="بحث">
                        	</form>
                    		
                    	</div><!-- .container-wrapper /-->
                    </div><!-- .mag-box /-->

        <?php endif;?>
        </div>
            <!-- pagination -->
            <?php get_template_part('pagination');?>

        
        </div>
    </div>

   <?php get_sidebar();?>
   <?php get_footer();?>
