<div id="pagination">
    <div class="container">
        <div class="nav-previous align-left pagination-part">
                <?php next_posts_link('الصفحة التالية <span class="fa" aria-hidden="true"></span>')?>
        </div>

        <div class="nav-next align-right pagination-part">
                <?php previous_posts_link('<span class="fa" aria-hidden="true"></span>
                الصفحة السابقة')?>
        </div>
    </div>
</div>

