<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

// Mobile Menu color
$wp_customize->add_section( 
	'baghdad_news_Mobile_mobile_header_bg', 
	array(
		'title'			=> esc_html__( 'Header color for mobile screens', 'baghdad-news' ),
		'priority'		=> 10,
		'panel'    => 'Personalize-the-phone',
	) 
);

// light

$wp_customize->add_setting('baghdad_news_Mobile_mobile_header_bg_st', array(
    'default' =>  '#ffffff',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_Mobile_mobile_header_bg_st', array(
        'label'=> esc_html__('Header color "light"', 'baghdad-news'),
        'section' => 'baghdad_news_Mobile_mobile_header_bg',
)) );


// dark
$wp_customize->add_setting('baghdad_news_Mobile_mobile_header_bg_dark_st', array(
    'default' =>  '#252525',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_Mobile_mobile_header_bg_dark_st', array(
        'label'=> esc_html__('Header color "Dark"', 'baghdad-news'),
        'section' => 'baghdad_news_Mobile_mobile_header_bg',
)) );

