<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

// Theme Customization Panel
$wp_customize->add_panel(
    'Personalize-the-phone',
    array(
        'title' => esc_html__( 'Personalize the phone', 'baghdad-news' ),
        'priority' => 20,
    )
);


// mobile-menu-layout
require get_template_directory().'/inc/customizer/Personalize-the-phone/mobile-menu-layout.php';
//mobile-header-bg
require get_template_directory().'/inc/customizer/Personalize-the-phone/mobile-header-bg.php';
// mobile-icon-menu
require get_template_directory().'/inc/customizer/Personalize-the-phone/mobile-icon-menu.php';
