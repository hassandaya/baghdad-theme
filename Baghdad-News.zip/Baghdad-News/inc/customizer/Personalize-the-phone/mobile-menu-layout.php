<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

 
 // Mobile Menu Layout

 $wp_customize->add_section( 'baghdad_news_Mobile_Menu_Layout', array(
    'title' => esc_html__('Mobile Menu Layout', 'baghdad-news'), 
    'panel' => 'Personalize-the-phone', 
    'priority' => 25 
 ));


       //Mobile Menu bg img
    $wp_customize->add_setting( 'baghdad_news_Mobile_Menu_bg_img', array( 
        'sanitize_callback' => 'sanitize_text_field' 
    ));

    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize, 'baghdad_news_Mobile_Menu_bg_img',
            array(
                'label' => __('Mobile Menu background images ', 'baghdad-news'),
                'section' => 'baghdad_news_Mobile_Menu_Layout'
        )
));

// Mobile Menu color

$wp_customize->add_setting('Mobile_Menu_color', array(
    'default' =>  '#9e9e9e',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'Mobile_Menu_color', array(
        'label'=>__('Text color', 'baghdad-news'),
        'section' => 'baghdad_news_Mobile_Menu_Layout',
)) );


// light

$wp_customize->add_setting('main_aree_mobile_back_color', array(
    'default' =>  '#ffffff',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'main_aree_mobile_back_color', array(
        'label'=> esc_html__('Mobile Menu background color "light"', 'baghdad-news'),
        'section' => 'baghdad_news_Mobile_Menu_Layout',
)) );


// dark
$wp_customize->add_setting('main_aree_mobile_back_color_dark', array(
    'default' =>  '#252525',
    'sanitize_callback' => 'sanitize_hex_color',
    // 'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'main_aree_mobile_back_color_dark', array(
        'label'=> esc_html__('Mobile Menu background color "Dark"', 'baghdad-news'),
        'section' => 'baghdad_news_Mobile_Menu_Layout',
)) );
