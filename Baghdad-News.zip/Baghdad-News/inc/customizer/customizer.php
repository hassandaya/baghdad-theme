<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


function learningWordpress_customize_register( $wp_customize ){ 
    
    // Load customize controls.
    require get_template_directory().'/inc/customizer/customizer-function/customizer-control.php';
    // customize color
    require get_template_directory() . '/inc/customizer/customize-color.php';
    // customize theme option
    require get_template_directory() . '/inc/customizer/themeoption-custoize.php';
    // banner option
    require get_template_directory() . '/inc/customizer/banner-option.php';
    // theme customize controls.
    require get_template_directory().'/inc/customizer/theme-cutomiz/theme-cutomiz.php';
    // Personalize the phone
    require get_template_directory().'/inc/customizer/Personalize-the-phone/Personalize-the-phone.php';
    // footer
    require get_template_directory().'/inc/customizer/footer/footer.php';
    // Advertisement
    require get_template_directory().'/inc/customizer/Advertisement/Advertisement.php';
}
add_action('customize_register','learningWordpress_customize_register');    
// Load customize default values.
    // customizer-default
    require get_template_directory().'/inc/customizer/customizer-function/customizer-default.php';
    // control choices
    require get_template_directory().'/inc/customizer/customizer-function/control-choices.php';
    // sanitize-callback
    require get_template_directory().'/inc/customizer/customizer-function/sanitize-callback.php';

