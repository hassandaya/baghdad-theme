<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


 
 $wp_customize->remove_section("colors");
    // color customize option
    $wp_customize->add_section('Customize_color', array(
        'title' =>__('Color Customize', 'baghdad-news'),
        'priority' => 30,
    ));


    //    back color
    $wp_customize->add_setting('lwp_back_color', array(
        'default' =>  '#e9f5fc',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_back_color', array(
            'label'=>__('Background color "light mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_back_color',
    )) );


    //    back dark color
    $wp_customize->add_setting('lwp_back_dark_color', array(
        'default' =>  '#262626',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'lwp_back_dark_color', array(
        'label'=>__('Background color "Dark mode"', 'baghdad-news'),
        'section'=> 'Customize_color',
        'settings'=> 'lwp_back_dark_color',
    )) );

    // window Color

    $wp_customize->add_setting('lwp_window_color', array(
        'default' =>  '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_window_color', array(
            'label'=>__('Window color"light mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_window_color',
    )) );

    // window dark Color

    $wp_customize->add_setting('lwp_window_dark_color', array(
        'default' =>  '#262626',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_window_dark_color', array(
            'label'=>__('Window color "Dark mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_window_dark_color',
    )) );


    // cover color light
    
    $wp_customize->add_setting('lwp_cover_color', array(
        'default' =>  '#e9f5fc',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_cover_color', array(
            'label'=>__('Cover color "light mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_cover_color',
    )) );


    // cover color dark
    
    $wp_customize->add_setting('lwp_cover_dark_color', array(
        'default' =>  '#2d2d2d',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_cover_dark_color', array(
            'label'=>__('Cover color "Dark mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_cover_dark_color',
    )) );


    // nav menu color light
    
    $wp_customize->add_setting('lwp_navMenu_color', array(
        'default' =>  '#fff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_navMenu_color', array(
            'label'=>__('Top menu color "light mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_navMenu_color',
    )) );


    // nav menu color dark
    
    $wp_customize->add_setting('lwp_navMenu_dark_color', array(
        'default' =>  '#16141b',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_navMenu_dark_color', array(
            'label'=>__('Top menu color "Dark mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_navMenu_dark_color',
    )) );


    // tapes Color

    $wp_customize->add_setting('lwp_tapes_color', array(    
        'default' =>  '#ff8500',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_tapes_color', array(
            'label'=>__('Tape color', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_tapes_color',
    )) );


    





    // text link Color

    $wp_customize->add_setting('lwp_text_link_color', array(
        'default' =>  '#587897',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_text_link_color', array(
            'label'=>__('Links color "light mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_text_link_color',
    )) );


    // text link dark Color

    $wp_customize->add_setting('lwp_text_link_dark_color', array(
        'default' =>  '#ececec',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_text_link_dark_color', array(
            'label'=>__('Links color "Dark mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_text_link_dark_color',
    )) );


    // text normal Color

    $wp_customize->add_setting('lwp_normal_text_color', array(
        'default' =>  '#3b3f3f',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_normal_text_color', array(
            'label'=>__('Text color "light mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_normal_text_color',
    )) );


    // text dark normal Color

    $wp_customize->add_setting('lwp_normal_dark_text_color', array(
        'default' =>  '#8c867f',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_normal_dark_text_color', array(
            'label'=>__('Text color "Dark mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_normal_dark_text_color',
    )) );

    //  info Color

    $wp_customize->add_setting('lwp_info_color', array(
        'default' =>  '#8c867f',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_info_color', array(
            'label'=>__('Info color "light mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_info_color',
    )) );


    //  dark info Color

    $wp_customize->add_setting('lwp_dark_info_color', array(
        'default' =>  '#6b6b6b',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'refresh',
    ));


    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
        'lwp_dark_info_color', array(
            'label'=>__('Info color "Dark mode"', 'baghdad-news'),
            'section'=> 'Customize_color',
            'settings'=> 'lwp_dark_info_color',
    )) 
);

//  header cover Color

$wp_customize->add_setting('lwp_Header_background', array(
    'default' =>  '#e9f5fc',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'lwp_Header_background', array(
        'label'=>__('Header background "light mode"', 'baghdad-news'),
        'section'=> 'header_image',
        'settings'=> 'lwp_Header_background',
)) );


//  dark Header_background

$wp_customize->add_setting('lwp_dark_Header_background', array(
    'default' =>  '#2d2d2d',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'lwp_dark_Header_background', array(
        'label'=>__('Header background "Dark mode"', 'baghdad-news'),
        'section'=> 'header_image',
        'settings'=> 'lwp_dark_Header_background',
)) 
);

// color customize option
$wp_customize->add_section('header_image', array(
    'title' =>__('Header Customize', 'baghdad-news'),
    'priority' => 30,
));




















