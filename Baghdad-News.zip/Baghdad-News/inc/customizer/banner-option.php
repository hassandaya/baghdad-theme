<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


$wp_customize->add_panel('frontpage_option_panel',
    array(
        'title'      => esc_html__('Frontpage Options', 'baghdad-news'),
        'priority'   => 199,
        'capability' => 'edit_theme_options',
    ));


    // banner flashe
    require get_template_directory() . '/inc/customizer/banner/banner-2.php';


     

