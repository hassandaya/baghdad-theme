<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

if (!function_exists('baghdad_news_get_default_theme_options')):

/**
 * Get default theme options
 *
 * @since 1.0.0
 *
 * @return array Default theme options.
 */
function baghdad_news_get_default_theme_options() {

    $defaults = array();
    // Preloader options section
    $defaults['enable_site_preloader'] = 1;

    // Header options section
    $defaults['header_layout'] = 'header-layout-1';


	return $defaults;

}

endif;


$default = baghdad_news_get_default_theme_options();

/**
 * Frontpage options section
 *
 * @package CoverNews
 */

function baghdad_news_sanitize_category_dropdown( $input ) {
	$cat = get_category_by_slug( $input );
	if ( empty( $cat ) ) {
		return 'all';
	}

	return $input;
}
