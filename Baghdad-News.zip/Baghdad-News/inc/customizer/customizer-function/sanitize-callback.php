<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

if ( !function_exists('baghdad_news_sanitize_select') ) {

    function baghdad_news_sanitize_select( $input, $setting ) {

        // Ensure input is a slug.
        $input = sanitize_key( $input );
        // Get list of choices from the control associated with the setting.
        $choices = $setting->manager->get_control( $setting->id )->choices;
        // If the input is a valid key, return it; otherwise, return the default.
        return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
    }

    // checkbox sanitization
	function baghdad_news_checkbox_sanitize( $input ) {
		if ( $input == 1 ) {
			return 1;
		} else {
			return '';
		}
    }
    
    // radio button sanitization
	function baghdad_news_related_posts_sanitize( $input ) {
		$valid_keys = array(
			'categories' => __( 'Related Posts By Categories', 'baghdad-news' ),
			'tags'       => __( 'Related Posts By Tags', 'baghdad-news' ),
		);
		if ( array_key_exists( $input, $valid_keys ) ) {
			return $input;
		} else {
			return '';
		}
	}
}