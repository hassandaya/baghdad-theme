<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

//site_layout choices
if( ! function_exists( 'baghdad_news_site_layout' ) ) {

	function baghdad_news_site_layout() {

		return array(
			'boxed_layout' => get_template_directory_uri() . '/photo/boxed_layout.png',
			'wide_layout' => get_template_directory_uri() . '/photo/wide_layout.png',
		);
	}
}

// side bar float choices
if( ! function_exists( 'baghdad_news_sidebar_positions' ) ) {

	function baghdad_news_sidebar_positions() {

		return array(
			'sidebar-left' => get_template_directory_uri() . '/photo/sidebar_left.png',
			'sidebar-right' => get_template_directory_uri() . '/photo/sidebar_right.png',
		);
	}
}
// tapes title theme option
if( ! function_exists( 'baghdad_news_tapes_title_options' ) ) {

	function baghdad_news_tapes_title_options() {

		return array(
			'one-option-title' => get_template_directory_uri() . '/photo/one-option-title.png',
			'tow-option-title' => get_template_directory_uri() . '/photo/tow-option-title.png',
		);
	}
}

// box style option
if( ! function_exists( 'baghdad_news_box_style' ) ) {

	function baghdad_news_box_style() {

		return array(
			'one-box-style' => get_template_directory_uri() . '/photo/one-box-style.png',
			'tow-box-style' => get_template_directory_uri() . '/photo/tow-box-style.png',
			'three-box-style' => get_template_directory_uri() . '/photo/three-box-style.png',
			'four-box-style' => get_template_directory_uri() . '/photo/four-box-style.png',
			'five-box-style' => get_template_directory_uri() . '/photo/timline-style.png',
		);
	}
}


// box shape option
if( ! function_exists( 'baghdad_news_box_shape' ) ) {

	function baghdad_news_box_shape() {

		return array(
			'outline-diagram' => get_template_directory_uri() . '/photo/outline-diagram.png',
			'clean' => get_template_directory_uri() . '/photo/clean.png',
		);
	}
}


// outline img style 

if( ! function_exists( 'baghdad_news_outline_img' ) ) {

	function baghdad_news_outline_img() {

		return array(
			'img-outline-none' => get_template_directory_uri() . '/photo/none-outline.png',
			'img-outline-1' => get_template_directory_uri() . '/photo/outline-1.png',
			'img-outline-2' => get_template_directory_uri() . '/photo/outline-2.png',
		);
	}
}

// Loading style 

if( ! function_exists( 'baghdad_news_Loading' ) ) {

	function baghdad_news_Loading() {

		return array(
			'none-loadin-style' => get_template_directory_uri() . '/photo/none-outline.png',
			'one-loadin-style' => get_template_directory_uri() . '/photo/one-loadin-style.png',
			'tow-loading-style'  => get_template_directory_uri() . '/photo/tow-loading-style.png',
		);
	}
}