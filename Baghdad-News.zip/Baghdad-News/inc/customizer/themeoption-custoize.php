<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


$wp_customize->add_panel('Baghdad_panel', array(
    'priority' => 1, 
    'capability'=> 'edit_theme_options', 
    'title' => __('Baghdad Theme Options', 'baghdad-news'
 ) ));

    // social media option
    $wp_customize->add_section( 'baghdad_news_section_social_media', array( 
        'title' => __('Social Media', 'baghdad-news'), 
        'panel' => 'Baghdad_panel',
        'priority' => 23 
     ) );

    
        /** Social Media */
        // facebook
        $wp_customize->add_setting('baghdad_news_facebook_url', array(
            'default' => '.', 
            'sanitize_callback' => 'sanitize_text_field',
            'transport' => 'refresh',
        ));

        $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'baghdad_news_facebook_url', array(
            'label' => __('Facebook URL', 'baghdad-news'), 
            'section' => 'baghdad_news_section_social_media', 
            'settings' => 'baghdad_news_facebook_url', 
            'type' => 'text', 
            'priority' => 1
        )));
        // twitter
        $wp_customize->add_setting('baghdad_news_twitter_url', array(
            'default' => '.',
            'sanitize_callback' => 'sanitize_text_field',
            'transport' => 'refresh',
        ));

        $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'baghdad_news_twitter_url', array(
            'label' => __('Twitter URL', 
            'baghdad-news'), 'section' => 'baghdad_news_section_social_media', 
            'settings' => 'baghdad_news_twitter_url', 
            'type' => 'text',
            'priority' => 2
        )));


        // instagram
        $wp_customize->add_setting('baghdad_news_instagram_url', array(
            'default' => '.',
            'sanitize_callback' => 'sanitize_text_field',
            'transport' => 'refresh',
        ));

        $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'baghdad_news_instagram_url', array(
            'label' => __('Instagram URL', 'baghdad-news'), 
            'section' => 'baghdad_news_section_social_media', 
            'settings' => 'baghdad_news_instagram_url', 
            'type' => 'text',
            'priority' => 3
        )));


        // youtube
        $wp_customize->add_setting('baghdad_news_youtube_url', array(
            'default' => '.',
             'sanitize_callback' => 'sanitize_text_field',
             'transport' => 'refresh',
        )); 

        $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'baghdad_news_youtube_url', array(
            'label' => __('Youtube URL', 'baghdad-news'), 
            'section' => 'baghdad_news_section_social_media', 
            'settings'  => 'baghdad_news_youtube_url', 
            'type' => 'text',
             'priority' => 6
        )));

        // mail
        $wp_customize->add_setting('baghdad_news_mail_url', array(
            'default' => '.', 
            'sanitize_callback' => 'sanitize_text_field',
            'transport' => 'refresh',
        ));

        $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'baghdad_news_mail_url', array(
            'label' => __('Mail ', 'baghdad-news'), 
            'section' => 'baghdad_news_section_social_media', 
            'settings' => 'baghdad_news_mail_url', 
            'type' => 'text', 
            'priority' => 7
        )));


            
        // Rss
        $wp_customize->add_setting('baghdad_news_rss_url', array(
            'default' => '.', 
            'sanitize_callback' => 'sanitize_text_field',
            'transport' => 'refresh',
        ));

        $wp_customize->add_control(new WP_Customize_Control($wp_customize, 'baghdad_news_rss_url', array(
            'label' => __('Rss URL', 'baghdad-news'), 
            'section' => 'baghdad_news_section_social_media', 
            'settings' => 'baghdad_news_rss_url', 
            'type' => 'text', 
            'priority' => 8
        ))
    );


    // logo option

    $wp_customize->add_section( 'baghdad_news_section_logo', array(
        'title' => esc_html__('Theme Logo', 'baghdad-news'), 
        'panel' => 'Baghdad_panel', 
        'priority' => 25 
     ));


           // Logo footer
        $wp_customize->add_setting( 'baghdad_news_nav_logo_url', array(
            'default' =>  get_template_directory_uri() . '/photo/Baghdad.png', 
            'sanitize_callback' => 'sanitize_text_field' 
        ));

        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize, 'baghdad_news_nav_logo_url',
                array(
                    'label' => __('nav Logo ', 'baghdad-news'),
                    'section' => 'baghdad_news_section_logo'
            )
    ));

?>
