<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */



$wp_customize->add_section( 
    'baghdad_news_outline_img', 
    array(
        'title'			=> esc_html__( 'Photo frame style', 'baghdad-news' ),
        'panel'			=> 'theme-custoizer-panel',
    ) 
);







$wp_customize->add_setting( 
    'baghdad_news_select_outline_img', 
    array(
        'sanitize_callback'	=> 'baghdad_news_sanitize_select',
        'default'			=> 'tow-box-style',
    ) 
);



$wp_customize->add_control( 
    new COLORMAG_Image_Radio_Control( 
        $wp_customize,
        'baghdad_news_select_outline_img', 
        array(
            'label'				=> esc_html__( 'Select Photo frame style', 'baghdad-news' ),
            'description'       => '',
            'section'			=> 'baghdad_news_outline_img',
            'type'				=> 'select',
            'choices'			=> baghdad_news_outline_img(), 
        ) 
    )
);


// text link Color

$wp_customize->add_setting('lwp_outline_img_color', array(
    'default' =>  '#587897',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'lwp_outline_img_color', array(
        'label'=>__('Photo frame color"', 'baghdad-news'),
        'section'=> 'baghdad_news_outline_img',
        'settings'=> 'lwp_outline_img_color',
)) );