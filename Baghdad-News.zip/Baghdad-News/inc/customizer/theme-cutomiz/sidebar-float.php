<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */




			$wp_customize->add_section( 
				'baghdad_news_blog_page_options', 
				array(
					'title'			=> esc_html__( 'Blog Page', 'baghdad-news' ),
					'panel'			=> 'theme-custoizer-panel',
				) 
			);
		





			// Select Sidebar Position

			$wp_customize->add_setting( 
				'baghdad_news_select_blog_sidebar_position', 
				array(
					'sanitize_callback'	=> 'baghdad_news_sanitize_select',
					'default'			=> 'sidebar-left',
				) 
			);

			$wp_customize->add_control( 
				new COLORMAG_Image_Radio_Control( 
					$wp_customize,
					'baghdad_news_select_blog_sidebar_position', 
					array(
						'label'				=> esc_html__( 'Select Sidebar Position', 'baghdad-news' ),
						'section'			=> 'baghdad_news_blog_page_options',
						'type'				=> 'select',
						'choices'			=> baghdad_news_sidebar_positions(), 
					) 
				)
			);
		


