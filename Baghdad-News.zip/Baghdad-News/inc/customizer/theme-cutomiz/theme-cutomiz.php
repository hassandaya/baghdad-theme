<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

 
// Theme Customization Panel
$wp_customize->add_panel(
    'theme-custoizer-panel',
    array(
        'title' => esc_html__( 'Theme Customization', 'baghdad-news' ),
        'priority' => 20,
    )
);




// site layout
require get_template_directory().'/inc/customizer/theme-cutomiz/site-layout.php';
// sidebar Float
require get_template_directory().'/inc/customizer/theme-cutomiz/sidebar-float.php';
// direction wp
require get_template_directory().'/inc/customizer/theme-cutomiz/tapes-title.php';
// box-style
require get_template_directory().'/inc/customizer/theme-cutomiz/box-style.php';
// single posts panel option
require get_template_directory() . '/inc/customizer/theme-cutomiz/single-posts.php';
// box-shape option
require get_template_directory() . '/inc/customizer/theme-cutomiz/box-shape.php';
// img outline options
require get_template_directory().'/inc/customizer/theme-cutomiz/img-outline.php';
// loading
require get_template_directory().'/inc/customizer/theme-cutomiz/loading.php';