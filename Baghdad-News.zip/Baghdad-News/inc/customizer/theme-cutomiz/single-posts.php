<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


 
	// related posts
	$wp_customize->add_section( 'baghdad_news_related_posts_section', array(
		'priority' => 4,
		'title'    => __( 'Related Posts', 'baghdad-news' ),
		'panel'    => 'theme-custoizer-panel',
	) );

	$wp_customize->add_setting( 'baghdad_news_related_posts_activate', array(
		'default'           => 0,
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'baghdad_news_checkbox_sanitize',
		'transport'         => $customizer_selective_refresh,
	) );

	$wp_customize->add_control( 'baghdad_news_related_posts_activate', array(
		'type'     => 'checkbox',
		'label'    => __( 'Check to activate the related posts', 'baghdad-news' ),
		'section'  => 'baghdad_news_related_posts_section',
		'settings' => 'baghdad_news_related_posts_activate',
	) );

	// Selective refresh for related posts feature
	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'baghdad_news_related_posts_activate', array(
			'selector'        => '.related-posts',
			'render_callback' => '',
		) );
	}

	$wp_customize->add_setting( 'baghdad_news_related_posts', array(
		'default'           => 'categories',
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'baghdad_news_related_posts_sanitize',
	) );

	$wp_customize->add_control( 'baghdad_news_related_posts', array(
		'type'     => 'radio',
		'label'    => __( 'Related Posts Must Be Shown As:', 'baghdad-news' ),
		'section'  => 'baghdad_news_related_posts_section',
		'settings' => 'baghdad_news_related_posts',
		'choices'  => array(
			'categories' => __( 'Related Posts By Categories', 'baghdad-news' ),
			'tags'       => __( 'Related Posts By Tags', 'baghdad-news' ),
		),
	) );
