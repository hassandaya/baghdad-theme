<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */



			$wp_customize->add_section( 
				'baghdad_news_tapes_title_options', 
				array(
					'title'			=> esc_html__( 'Title Tapes', 'baghdad-news' ),
					'panel'			=> 'theme-custoizer-panel',
				) 
			);
		





			// Select Sidebar Position

			$wp_customize->add_setting( 
				'baghdad_news_select_tapes_title', 
				array(
					'sanitize_callback'	=> 'baghdad_news_sanitize_select',
					'default'			=> 'one-option-title',
				) 
			);

			$wp_customize->add_control( 
				new COLORMAG_Image_Radio_Control( 
					$wp_customize,
					'baghdad_news_select_tapes_title', 
					array(
						'label'				=> esc_html__( 'Select Title Tapes', 'baghdad-news' ),
						'section'			=> 'baghdad_news_tapes_title_options',
						'type'				=> 'select',
						'choices'			=> baghdad_news_tapes_title_options(), 
					) 
				)
			);