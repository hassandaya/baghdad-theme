<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */



$wp_customize->add_section( 
    'baghdad_news_Loading', 
    array(
        'title'			=> esc_html__( 'Loading style', 'baghdad-news' ),
        'panel'			=> 'theme-custoizer-panel',
    ) 
);







$wp_customize->add_setting( 
    'baghdad_news_Loading', 
    array(
        'sanitize_callback'	=> 'baghdad_news_sanitize_select',
        'default'			=> 'one-loadin-style',
    ) 
);



$wp_customize->add_control( 
    new COLORMAG_Image_Radio_Control( 
        $wp_customize,
        'baghdad_news_Loading', 
        array(
            'label'				=> esc_html__( 'Select Loading style', 'baghdad-news' ),
            'description'       => '',
            'section'			=> 'baghdad_news_Loading',
            'type'				=> 'select',
            'choices'			=> baghdad_news_Loading(), 
        ) 
    )
);


