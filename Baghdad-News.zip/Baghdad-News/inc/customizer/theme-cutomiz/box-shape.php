<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */





			$wp_customize->add_section( 
				'baghdad_news_box_shape', 
				array(
					'title'			=> esc_html__( 'Box shape', 'baghdad-news' ),
					'panel'			=> 'theme-custoizer-panel',
					'description'       => esc_html__('The second option does not work on the color of windows', 'baghdad-news' ),
				) 
			);
		





			// Select Sidebar Position

			$wp_customize->add_setting( 
				'baghdad_news_select_box_shape', 
				array(
					'sanitize_callback'	=> 'baghdad_news_sanitize_select',
					'default'			=> 'outline-diagram',
				) 
			);

			$wp_customize->add_control( 
				new COLORMAG_Image_Radio_Control( 
					$wp_customize,
					'baghdad_news_select_box_shape', 
					array(
						'label'				=> esc_html__( 'Select Partition diagram', 'baghdad-news' ),
						
						'section'			=> 'baghdad_news_box_shape',
						'type'				=> 'select',
						'choices'			=> baghdad_news_box_shape(), 
					) 
				)
			);