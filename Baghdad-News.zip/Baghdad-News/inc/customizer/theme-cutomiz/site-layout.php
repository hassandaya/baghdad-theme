<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */



$wp_customize->add_section( 
	'baghdad_news_site_layout_options', 
	array(
		'title'			=> esc_html__( 'Site Layout', 'baghdad-news' ),
		'priority'		=> 10,
		'panel'    => 'theme-custoizer-panel',
	) 
);




$wp_customize->add_setting( 
	'baghdad_news_select_site_layout', 
	array(
		'sanitize_callback'		=> 'baghdad_news_sanitize_select',
		'default'				=> 'boxed_layout', 
	) 
);

$wp_customize->add_control( 
	new COLORMAG_Image_Radio_Control( 
	    $wp_customize,
	'baghdad_news_select_site_layout', 
	array(
		'label'				=> esc_html__( 'Select Site Layout', 'baghdad-news' ),
		'section'			=> 'baghdad_news_site_layout_options',
		'type'				=> 'select',
		'choices'			=> baghdad_news_site_layout(), 
	) 
));



