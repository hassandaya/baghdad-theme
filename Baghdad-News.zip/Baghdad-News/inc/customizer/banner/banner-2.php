<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


$wp_customize->add_section(
    'baghdad_news1',
    array(
        'title'    => esc_html__( 'Section 1', 'baghdad-news' ),
        'priority' => 1,
        'description' => esc_html__( 'This section appears on the front page only', 'baghdad-news' ),
        'panel'    => 'frontpage_option_panel',
    )
);

$wp_customize->add_section(
    'baghdad_news2',
    array(
        'title'    => esc_html__( 'Section 2', 'baghdad-news' ),
        'description' => esc_html__( 'This section appears on the front page only', 'baghdad-news' ),
        'priority' => 1,
        'panel'    => 'frontpage_option_panel',
    )
);

$wp_customize->add_section(
    'baghdad_news3',
    array(
        'title'    => esc_html__( 'Lower Part', 'baghdad-news' ),
        'description' => esc_html__( 'This section appears on all pages on Footer', 'baghdad-news' ),
        'priority' => 1,
        'panel'    => 'frontpage_option_panel',
    )
);

$wp_customize->add_section(
    'baghdad_news4',
    array(
        'title'    => esc_html__( 'Main Banner Section', 'baghdad-news' ),
        'description' => esc_html__( 'This section appears on the front page and the home page', 'baghdad-news' ),
        'priority' => 1,
        'panel'    => 'frontpage_option_panel',
    )
);

$wp_customize->add_section(
    'baghdad_news5',
    array(
        'title'    => esc_html__( 'Flash Posts', 'baghdad-news' ),
        'description' => esc_html__( 'This section appears on all pages except the home page and the front pagee', 'baghdad-news' ),
        'priority' => 1,
        'panel'    => 'frontpage_option_panel',
    )
);



for ( $i = 1; $i <= 5; $i ++ ) {
    $baghdad_news_secton_name = '';
    switch ( $i ) {
        case 1:
            $baghdad_news_secton_name = esc_html__( 'Section 1', 'baghdad-news' );
            break;
        case 2:
            $baghdad_news_secton_name = esc_html__( 'Section 2', 'baghdad-news' );
            break;
        case 3:
            $baghdad_news_secton_name = esc_html__( 'Lower Part', 'baghdad-news' );
            break;
        case 4:
            $baghdad_news_secton_name = esc_html__( 'Main Banner Section', 'baghdad-news' );
            break;
        case 5:
            $baghdad_news_secton_name = esc_html__( 'Flash Posts', 'baghdad-news' );
            break;
    }
    $wp_customize->add_setting(
        'baghdad_news' . $i . '_disable',
        array(
            'defalt'            => false,
            'sanitize_callback' => 'sanitize_text_field',
        )
    );

    $wp_customize->add_setting(
        'baghdad_news' . $i . '_fullwidth',
        array(
            'defalt'            => false,
            'sanitize_callback' => 'sanitize_text_field',
        )
    );

    $wp_customize->add_setting(
        'baghdad_news' . $i . '_title',
        array(
            'default'           => $baghdad_news_secton_name,
            'transport'         => 'postMessage',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );

    $wp_customize->add_setting(
        'baghdad_news' . $i . '_category',
        array(
            'default'           => 'all',
            'transport'         => 'postMessage',
            'sanitize_callback' => 'baghdad_news_sanitize_category_dropdown',
        )
    );

    $wp_customize->add_setting(
        'baghdad_news' . $i . '_max_posts',
        array(
            'default'           => 6,
            'transport'         => 'postMessage',
            'sanitize_callback' => 'absint',
        )
    );
}// End for().

for ( $i = 1; $i <= 2; $i ++ ) {
    $wp_customize->add_control(
        'baghdad_news' . $i . '_disable',
        array(
            'type'     => 'checkbox',
            'label'    => esc_html__( 'Disable section', 'baghdad-news' ),
            'section'  => 'baghdad_news' . $i,
            'priority' => 1,
        )
    );

    $wp_customize->add_control(
        'baghdad_news' . $i . '_title',
        array(
            'label'    => esc_html__( 'Title', 'baghdad-news' ),
            'section'  => 'baghdad_news' . $i,
            'priority' => 3,
        )
    );

    $wp_customize->add_control(
        new IseleMagCategorySelector(
            $wp_customize,
            'baghdad_news' . $i . '_category',
            array(
                'label'    => esc_html__( 'Category', 'baghdad-news' ),
                'section'  => 'baghdad_news' . $i,
                'priority' => 4,
            )
        )
    );



}// End for().

for ( $i = 3; $i <= 5; $i ++ ) {
    $wp_customize->add_control(
        'baghdad_news' . $i . '_disable',
        array(
            'type'     => 'checkbox',
            'label'    => esc_html__( 'Disable section', 'baghdad-news' ),
            'section'  => 'baghdad_news' . $i,
            'priority' => 1,
        )
    );

    $wp_customize->add_control(
        'baghdad_news' . $i . '_title',
        array(
            'label'    => esc_html__( 'Title', 'baghdad-news' ),
            'section'  => 'baghdad_news' . $i,
            'priority' => 3,
        )
    );

    $wp_customize->add_control(
        new IseleMagCategorySelector(
            $wp_customize,
            'baghdad_news' . $i . '_category',
            array(
                'label'    => esc_html__( 'Category', 'baghdad-news' ),
                'section'  => 'baghdad_news' . $i,
                'priority' => 4,
            )
        )
    );

    $wp_customize->add_control(
        'baghdad_news' . $i . '_max_posts',
        array(
            'label'       => esc_html__( 'Number of posts in this section', 'baghdad-news' ),
            'description' => esc_html__( 'This section should not be set to less than 1', 'baghdad-news' ),
            'section'     => 'baghdad_news' . $i,
            'type'        => 'number',
            'input_attrs' => array(
                'min'  => - 1,
                'step' => 1,
            ),
            'priority'    => 5,
        )
    );

}// End for().




