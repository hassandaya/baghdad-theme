<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

$wp_customize->add_setting(
    'baghdad_news_Copyrights_text',
    array(
        'default'           => esc_html__( 'Copyright © All rights reserved.', 'baghdad-news' ),
        'transport'         => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field',
    )
);



$wp_customize->add_control(
    'baghdad_news_Copyrights_text',
    array(
        'label'    => esc_html__( 'Copyrights Text', 'baghdad-news' ),
        'section'  => 'baghdad_news_Copyrights_text_section',
        'priority' => 3,
    )
);

$wp_customize->add_section(
    'baghdad_news_Copyrights_text_section',
    array(
        'title'    => esc_html__( 'Copyrights Text', 'baghdad-news' ),
        'description' => esc_html__( "If you do not want to appear. Wipe what's inside", 'baghdad-news' ),
        'priority' => 1,
        'panel'    => 'footer',
    )
);

 // Background Color

 $wp_customize->add_setting('baghdad_news_Copyrights_Background_color', array(
    'default' =>  '#587897',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_Copyrights_Background_color', array(
        'label'=> esc_html__('Copyrights Background Color', 'baghdad-news'),
        'section' => 'baghdad_news_Copyrights_text_section',
)) );

 // text Color

 $wp_customize->add_setting('baghdad_news_Copyrights_text_color', array(
    'default' =>  '#fff',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_Copyrights_text_color', array(
        'label'=> esc_html__('Copyrights Text Color', 'baghdad-news'),
        'section' => 'baghdad_news_Copyrights_text_section',
)) );

