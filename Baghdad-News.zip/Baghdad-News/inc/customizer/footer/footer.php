<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

// Theme Customization Panel
$wp_customize->add_panel(
    'footer',
    array(
        'title' => esc_html__( 'Footer', 'baghdad-news' ),
        'priority' => 20,
    )
);

 // Footer Color`s

 $wp_customize->add_section( 'baghdad_news_footer_color`s', array(
    'title' => esc_html__('Footer Color`s', 'baghdad-news'), 
    'panel' => 'footer', 
    'priority' => 25 
 ));


 // Background

$wp_customize->add_setting('baghdad_news_footer_Background', array(
    'default' =>  '#333',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_footer_Background', array(
        'label'=> esc_html__('Footer Background', 'baghdad-news'),
        'section' => 'baghdad_news_footer_color`s',
)) );

 // Titile Color

$wp_customize->add_setting('baghdad_news_footer_titile_color', array(
    'default' =>  '#adacac',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_footer_titile_color', array(
        'label'=> esc_html__('Footer Title Color', 'baghdad-news'),
        'section' => 'baghdad_news_footer_color`s',
)) );

 // Link Color

$wp_customize->add_setting('baghdad_news_footer_link_color', array(
    'default' =>  '#fff',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_footer_link_color', array(
        'label'=> esc_html__('Footer Link Color', 'baghdad-news'),
        'section' => 'baghdad_news_footer_color`s',
)) );


 // text Color

$wp_customize->add_setting('baghdad_news_footer_text_color', array(
    'default' =>  '#8c867f',
    'sanitize_callback' => 'sanitize_hex_color',
    'transport' => 'refresh',
));


$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize,
    'baghdad_news_footer_text_color', array(
        'label'=> esc_html__('Footer Text Color', 'baghdad-news'),
        'section' => 'baghdad_news_footer_color`s',
)) );


//Copyrights
require get_template_directory().'/inc/customizer/footer/Copyrights.php';
