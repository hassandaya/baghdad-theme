<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

 
// advertisement before  footer
$wp_customize->add_section(
    'baghdad_news_Advertisement_before_footer_section',
    array(
        'title'    => esc_html__( 'Advertisement before Footer', 'baghdad-news' ),
        'description' => esc_html__( "If you do not want to appear. Wipe what's inside", 'baghdad-news' ),
        'priority' => 10,
        'panel'    => 'baghdad_news_Advertisement',
    )
);

// Advertisement Code

$wp_customize->add_setting(
    'baghdad_news_Advertisement_before_footer_Code',
    array(
        'transport'         => 'postMessage',
        // 'sanitize_callback' => 'sanitize_text_field',
    )
);



$wp_customize->add_control(
    'baghdad_news_Advertisement_before_footer_Code',
    array(
        'label'    => esc_html__( 'Code Advertisement before Footer', 'baghdad-news' ),
        'section'  => 'baghdad_news_Advertisement_before_footer_section',
        'type'        => 'textarea',
        'priority' => 3,
    )
);



// Advertisement url

 $wp_customize->add_setting(
    'baghdad_news_Advertisement_before_footer_url',
    array(
        'transport'         => 'postMessage',
        'sanitize_callback' => 'sanitize_text_field',
    )
);



$wp_customize->add_control(
    'baghdad_news_Advertisement_before_footer_url',
    array(
        'label'    => esc_html__( '-OR- "URL" Advertisement before Footer', 'baghdad-news' ),
        'section'  => 'baghdad_news_Advertisement_before_footer_section',
        'priority' => 3,
    )
);





// img Advertisement
$wp_customize->add_setting( 'baghdad_news_Advertisement_before_footer_img', array(
    'sanitize_callback' => 'sanitize_text_field' 
));

$wp_customize->add_control(
    new WP_Customize_Image_Control(
        $wp_customize, 'baghdad_news_Advertisement_before_footer_img',
        array(
            'label' =>  esc_html__( '-AND- "picture" Advertisement before Footer', 'baghdad-news' ),
            'section'  => 'baghdad_news_Advertisement_before_footer_section',
    )
));
