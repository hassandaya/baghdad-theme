<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

 $wp_customize->add_panel(
    'baghdad_news_Advertisement',
    array(
        'title'    => esc_html__( 'Advertisement', 'baghdad-news' ),
        'priority' => 5,
    )
);
 
// Advertisement-article
require get_template_directory().'/inc/customizer/Advertisement/Advertisement-article.php';
// Advertisement-article-footer
require get_template_directory().'/inc/customizer/Advertisement/Advertisement-article-footer.php';
// In the middle of the front page
require get_template_directory().'/inc/customizer/Advertisement/middle-of-front-page.php';
// Advertisement before archive
require get_template_directory().'/inc/customizer/Advertisement/Advertisement-before-archive.php';