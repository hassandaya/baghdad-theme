




<div class="author-box">

<div class="tapes-title">
    <h3>
        <?php the_author_posts_link();?> 
        <i class="fa fa-address-card"></i>
    </h3>
    <div class="stripe-line"></div>
</div>
   <section class="bost-box-single author-cover" style="background-image: url(<?php echo ( get_the_author_meta( 'author-cover-img') ); ?>);"></section>

    <div class=" bost-box-single autor-meta">
        <div class="author-avatar-img">
             <?php echo get_avatar( $comment, 90 ); ?>
        </div>

        <h1 class="autor-mobile-name"><?php the_author_posts_link();?> </h1>

        

        <div class="author-dec">
            <?php the_author_meta('description'); ?>
        </div>

        <div class="author-social">

            <?php 
                // Get the id of the post's author.
                $author_id = get_the_author_meta( 'ID' );

                // Get WP_User object for the author.
                $author_userdata = get_userdata( $author_id );

                // Get the author's website. It's stored in the wp_users table in the user_url field.
                $author_website = $author_userdata->data->user_url;

                // Get the rest of the author links. These are stored in the 
                // wp_usermeta table by the key assigned in wpse_user_contactmethods()
                $author_facebook = get_the_author_meta( 'facebook', $author_id );
                $author_twitter  = get_the_author_meta( 'twitter', $author_id  );
                $author_linkedin = get_the_author_meta( 'instagram', $author_id );
                $author_youtube  = get_the_author_meta( 'youtube', $author_id  );

            ?>

            <ul class="author-social-list">    
                <?php

                    if ( $author_website ) {
                        printf( '<li><a class="web-site" href="%s"><i class="fa fa-home" aria-hidden="true"></i></a></li>',                                        
                                esc_url( $author_website )
                        );
                    }


                    if ( $author_facebook ) {
                        printf( '<li><a class="facebook" href="%s"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>',
                                esc_url( $author_facebook )
                        );
                       }
                    
                                            
                    if ( $author_twitter ) {
                        printf( '<li><a class="twitter " href="%s"><i class="fa fa-twitter" ></i></a></li>',
                                esc_url( $author_twitter )
                        );
                    }
                    
                    if ( $author_linkedin ) {
                        printf( '<li> <a class="instgram" href="%s"><i class="fa fa-instagram tapes-color"></i></a></li>',
                                esc_url( $author_linkedin )
                        );
                    }

                   if ( $author_youtube ) {
                        printf( '<li><a class="youtube" href="%s"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>',
                            esc_url( $author_youtube )
                        );
                    } 

                    
                ?>

                
            </ul>

            <span class="suthor-post-no">
                <i class="fa fa-clone"></i>
                <?php echo get_the_author_posts(); ?>
                <span class="author-location">&nbsp;
                <?php $baghdad_news_author_Location = get_the_author_meta( 'author-Location') ?>
                <?php if ( ! empty( $baghdad_news_author_Location ) ) { ?>
                    <i class="fa fa-street-view"></i>
                    <?php echo esc_attr( $baghdad_news_author_Location ); ?>
                <?php } else {
	                if ( is_customize_preview() ) {
                    }
                }?></span>
            </span>
        </div>
    </div>
</div>
