<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


if( ! class_exists( 'BG_N_ADS125_WIDGET' )){

	/**
	 * Widget API: BG_N_ADS125_WIDGET class
	 */
	 class BG_N_ADS125_WIDGET extends WP_Widget {


		public function __construct(){
			$widget_ops  = array( 'classname' => 'stream-item-125-widget' );
			parent::__construct( 'stream-item-125-widget', apply_filters( 'theme_name', 'BD-N' ) .' - '.esc_html__( 'Ads ', 'baghdad-news' ) , $widget_ops );	}

		/**
		 * Outputs the content for the widget instance.
		 */
		public function widget( $args, $instance ){

			/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
			$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

			$new_window = isset( $instance['new_window'] ) ? ' target="_blank"' : '';
			$nofollow   = isset( $instance['nofollow'] ) ? ' rel="nofollow noopener"' : '';

			if( ! empty( $instance['tran_bg'] )){
				$args['before_widget'] = '<div id="'. $args['widget_id'] .'" class="widget stream-item-125-widget widget-content-only">';
				$args['after_widget']  = '</div>';
				$instance['title']     = '';
			}


			echo ( $args['before_widget'] );

			if ( ! empty($instance['title']) ){
				echo ( $args['before_title'] . $instance['title'] . $args['after_title'] );
			}

			echo '<ul class="dise-adds">';

			for($i=1 ; $i<11 ; $i++ ){

				if( ! empty( $instance['e3lan'.$i.'_code'] )){
					echo'<li>';
					echo do_shortcode( $instance['e3lan'.$i.'_code'] );
					echo '</li>';
				}

				elseif( ! empty( $instance['e3lan'.$i.'_img'] )){
					echo '<li>';
					if( ! empty( $instance['e3lan'.$i.'_url'] )){

						$url = apply_filters( 'BG_NLabs/ads_url', $instance['e3lan'.$i.'_url'] );
						echo '<a href="'. esc_url( $url ) .'"'. $new_window . $nofollow .'>';
					}

					echo '<img src="'. $instance['e3lan'.$i.'_img'] .'" width="125" height="125" alt="">';

					if( ! empty( $instance['e3lan'.$i.'_url'] )){
						echo '</a>';
					}
				echo '</li>';
				}
			}

			echo '</ul>';

			echo ( $args['after_widget'] );
		}

		/**
		 * Handles updating settings for widget instance.
		 */
		public function update( $new_instance, $old_instance ){
			$instance               = $old_instance;
			$instance['title']      = sanitize_text_field( $new_instance['title'] );
			$instance['tran_bg']    = $new_instance['tran_bg'];
			$instance['new_window'] = $new_instance['new_window'];
			$instance['nofollow']   = $new_instance['nofollow'];

			for($i=1 ; $i<11 ; $i++ ){
				$instance['e3lan'.$i.'_img']  = $new_instance['e3lan'.$i.'_img'];
				$instance['e3lan'.$i.'_url']  = $new_instance['e3lan'.$i.'_url'];
				$instance['e3lan'.$i.'_code'] = $new_instance['e3lan'.$i.'_code'];
			}

			return $instance;
		}

		/**
		 * Outputs the settings form for the widget.
		 */
		public function form( $instance ){
			$defaults = array( 'title' =>esc_html__( 'Advertisement', 'baghdad-news') );
			$instance = wp_parse_args( (array) $instance, $defaults );

			$title      = isset( $instance['title'] )      ? $instance['title'] : '';
			$tran_bg    = isset( $instance['tran_bg'] )    ? $instance['tran_bg'] : '';
			$new_window = isset( $instance['new_window'] ) ? $instance['new_window'] : '';
			$nofollow   = isset( $instance['nofollow'] )   ? $instance['nofollow'] : '';

			?>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title') ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>" class="widefat" type="text" />
			</p>

			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'tran_bg' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tran_bg' ) ); ?>" value="true" <?php checked( $tran_bg, 'true' ); ?> type="checkbox" />
				<label for="<?php echo esc_attr( $this->get_field_id( 'tran_bg' ) ); ?>"><?php esc_html_e( 'Show the ads only?', 'baghdad-news') ?></label>
			</p>

			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'new_window' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'new_window' ) ); ?>" value="true" <?php checked( $new_window, 'true' ); ?> type="checkbox" />
				<label for="<?php echo esc_attr( $this->get_field_id( 'new_window' ) ); ?>"><?php esc_html_e( 'Open links in a new window?', 'baghdad-news') ?></label>
			</p>

			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'nofollow' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'nofollow' ) ); ?>" value="true" <?php checked( $nofollow, 'true' ); ?> type="checkbox" />
				<label for="<?php echo esc_attr( $this->get_field_id( 'nofollow' ) ); ?>"><?php esc_html_e( 'Nofollow?', 'baghdad-news') ?></label>
			</p>

			<?php

			for($i=1 ; $i<11 ; $i++ ){ ?>
				<strong class="BG_N-widget-sub-title"><?php printf( esc_html__( 'Ad #%s'), $i ) ?></strong>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan'.$i.'_img' ) ); ?>"><?php esc_html_e( 'Image path:', 'baghdad-news' ) ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'e3lan'.$i.'_img' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan'.$i.'_img' ) ); ?>" value="<?php if( ! empty( $instance['e3lan'.$i.'_img'] ) ) echo esc_attr( $instance['e3lan'.$i.'_img'] ); ?>" placeholder="http://" class="widefat" type="text" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan'.$i.'_url' ) ); ?>"><?php esc_html_e( 'Ad URL' , 'baghdad-news') ?></label>
					<input id="<?php echo esc_attr( $this->get_field_id( 'e3lan'.$i.'_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan'.$i.'_url' ) ); ?>" value="<?php if( ! empty( $instance['e3lan'.$i.'_url'] ) ) echo esc_attr( $instance['e3lan'.$i.'_url'] ); ?>" placeholder="http://" class="widefat" type="text" />
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan'.$i.'_code' ) ); ?>"><strong><?php esc_html_e( '- OR -', 'baghdad-news') ?></strong> <?php esc_html_e( 'Code:', 'baghdad-news' ) ?></label>
					<textarea id="<?php echo esc_attr( $this->get_field_id( 'e3lan'.$i.'_code' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan'.$i.'_code' ) ); ?>" class="widefat" rows="5"><?php if( ! empty( $instance['e3lan'.$i.'_code'] ) ) echo esc_attr( $instance['e3lan'.$i.'_code'] ); ?></textarea>
				</p>
				<?php
			}
		}
	}



	/**
	 * Register the widget.
	 */
	add_action( 'widgets_init', 'BG_N_ads125_widget_register' );
	function BG_N_ads125_widget_register(){
		register_widget( 'BG_N_ADS125_WIDGET' );
	}

}




if( ! class_exists( 'BG_N_AD_WIDGET' )){

	/**
	 * Widget API: BG_N_AD_WIDGET class
	 */
	 class BG_N_AD_WIDGET extends WP_Widget {


		public function __construct(){
			$widget_ops  = array( 'classname' => 'stream-item-widget' );
			parent::__construct( 'stream-item-widget', apply_filters( 'theme_name', 'baghdad-news' ) .' - '.esc_html__( 'Ad', 'baghdad-news' ) , $widget_ops );	}

		/**
		 * Outputs the content for the widget instance.
		 */
		public function widget( $args, $instance ){

			/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
			$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

			$new_window = isset( $instance['new_window'] )  ? ' target="_blank"' : '';
			$nofollow   = isset( $instance['nofollow'] )    ? ' rel="nofollow noopener"' : '';
			$alt_text   = ! empty( $instance['e3lan_alt'] ) ? $instance['e3lan_alt'] : '';

			if( ! empty( $instance['tran_bg'] )){
				$args['before_widget'] = '<div id="'. $args['widget_id'] .'" class="widget stream-item-widget widget-content-only">';
				$args['after_widget']  = '</div>';
				$instance['title']     = '';
			}


			echo ( $args['before_widget'] );

			if ( ! empty($instance['title']) ){
				echo ( $args['before_title'] . $instance['title'] . $args['after_title'] );
			}

			echo '<div class="stream-item-widget-content">';

			# Ad Title
			if( ! empty( $instance['e3lan_title'] ) ){

				echo ! empty( $instance['e3lan_title_link'] ) ? '<a title="'. esc_attr( $instance['e3lan_title'] ) .'" href="'. esc_attr( $instance['e3lan_title_link'] ) .'" rel="nofollow noopener" target="_blank" class="stream-title">' : '<span class="stream-title">';
				echo $instance['e3lan_title'];
				echo ! empty( $instance['e3lan_title_link'] ) ? '</a>' : '</span>';
			}


			if( ! empty( $instance['e3lan_code'] )){
				echo do_shortcode( $instance['e3lan_code'] );
			}

			elseif( ! empty( $instance['e3lan_img'] )){
				if( ! empty( $instance['e3lan_url'] )){

					$url = apply_filters( 'BG_NLabs/ads_url', $instance['e3lan_url'] );
					echo '<a href="'. esc_url( $url ) .'"'. $new_window . $nofollow .'>';
				}

				echo '<img src="'. $instance['e3lan_img'] .'" width="728" height="90" alt="'. $alt_text .'">';

				if( ! empty( $instance['e3lan_url'] )){
					echo '</a>';
				}
			}

			echo '</div>';

			echo ( $args['after_widget'] );
		}

		/**
		 * Handles updating settings for widget instance.
		 */
		public function update( $new_instance, $old_instance ){
			$instance               = $old_instance;
			$instance['title']      = sanitize_text_field( $new_instance['title'] );
			$instance['tran_bg']    = $new_instance['tran_bg'];
			$instance['new_window'] = $new_instance['new_window'];
			$instance['nofollow']   = $new_instance['nofollow'];
			$instance['e3lan_img']  = $new_instance['e3lan_img'];
			$instance['e3lan_alt']  = $new_instance['e3lan_alt'];
			$instance['e3lan_url']  = $new_instance['e3lan_url'];
			$instance['e3lan_code'] = $new_instance['e3lan_code'];

			$instance['e3lan_title']      = $new_instance['e3lan_title'];
			$instance['e3lan_title_link'] = $new_instance['e3lan_title_link'];

			return $instance;
		}

		/**
		 * Outputs the settings form for the widget.
		 */
		public function form( $instance ){
			$defaults = array( 'title' =>esc_html__( 'Advertisement', 'baghdad-news') );
			$instance = wp_parse_args( (array) $instance, $defaults );

			$title      = isset( $instance['title'] ) ?      esc_attr( $instance['title'])      : '';
			$tran_bg    = isset( $instance['tran_bg'] ) ?    esc_attr( $instance['tran_bg'])    : '';
			$new_window = isset( $instance['new_window'] ) ? esc_attr( $instance['new_window']) : '';
			$nofollow   = isset( $instance['nofollow'] ) ?   esc_attr( $instance['nofollow'])   : '';

			?>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title') ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>" class="widefat" type="text" />
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan_title' ) ); ?>"><?php esc_html_e( 'Ad Title' ) ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'e3lan_title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan_title' ) ); ?>" value="<?php if( ! empty( $instance['e3lan_title'] ) ) echo esc_attr( $instance['e3lan_title'] ); ?>" class="widefat" type="text" />
				<small><?php esc_html_e( 'A title for the Ad, like Advertisement - leave this empty to disable.' ); ?></small>
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan_title_link' ) ); ?>"><?php esc_html_e( 'Ad Title Link' ) ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'e3lan_title_link' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan_title_link' ) ); ?>" value="<?php if( ! empty( $instance['e3lan_title_link'] ) ) echo esc_attr( $instance['e3lan_title_link'] ); ?>" class="widefat" placeholder="http://" type="text" />
			</p>

			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'tran_bg' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tran_bg' ) ); ?>" value="true" <?php checked( $tran_bg, 'true' ); ?> type="checkbox" />
				<label for="<?php echo esc_attr( $this->get_field_id( 'tran_bg' ) ); ?>"><?php esc_html_e( 'Show the ads only?') ?></label>
			</p>

			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'new_window' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'new_window' ) ); ?>" value="true" <?php checked( $new_window, 'true' ); ?> type="checkbox" />
				<label for="<?php echo esc_attr( $this->get_field_id( 'new_window' ) ); ?>"><?php esc_html_e( 'Open links in a new window?') ?></label>
			</p>

			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'nofollow' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'nofollow' ) ); ?>" value="true" <?php checked( $nofollow, 'true' ); ?> type="checkbox" />
				<label for="<?php echo esc_attr( $this->get_field_id( 'nofollow' ) ); ?>"><?php esc_html_e( 'Nofollow?') ?></label>
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan_img' ) ); ?>"><?php esc_html_e( 'Image path:' ) ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'e3lan_img' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan_img' ) ); ?>" value="<?php if( ! empty( $instance['e3lan_img'] ) ) echo esc_attr( $instance['e3lan_img'] ); ?>" class="widefat" placeholder="http://" type="text" />
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan_alt' ) ); ?>"><?php esc_html_e( 'Alternative Text For The image' ) ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'e3lan_alt' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan_alt' ) ); ?>" value="<?php if( ! empty( $instance['e3lan_alt'] ) ) echo esc_attr( $instance['e3lan_alt'] ); ?>" class="widefat" type="text" />
			<

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan_url' ) ); ?>"><?php esc_html_e( 'Ad URL' ) ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'e3lan_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan_url' ) ); ?>" value="<?php if( ! empty( $instance['e3lan_url'] ) ) echo esc_attr( $instance['e3lan_url'] ); ?>" class="widefat" placeholder="http://" type="text" />
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'e3lan_code' ) ); ?>"><strong><?php esc_html_e( '- OR -') ?></strong> <?php esc_html_e( 'Code:' ) ?></label>
				<textarea id="<?php echo esc_attr( $this->get_field_id( 'e3lan_code' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'e3lan_code' ) ); ?>" class="widefat" rows="5"><?php if( ! empty( $instance['e3lan_code'] ) ) echo esc_textarea( $instance['e3lan_code'] ); ?></textarea>
			</p>
			<?php
		}
	}



	/**
	 * Register the widget.
	 */
	add_action( 'widgets_init', 'BG_N_ad_widget_register' );
	function BG_N_ad_widget_register(){
		register_widget( 'BG_N_AD_WIDGET' );
	}

}
