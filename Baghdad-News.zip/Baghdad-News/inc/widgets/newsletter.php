<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


if( ! class_exists( 'BG_N_NEWSLETTER_WIDGET' )){

	/**
	 * Widget API: BG_N_NEWSLETTER_WIDGET class
	 */
	 class BG_N_NEWSLETTER_WIDGET extends WP_Widget {


		public function __construct(){
			$widget_ops = array( 'classname' => 'subscribe-widget' );
			parent::__construct( 'BG_N-newsletter', apply_filters( 'BG_NLabs/theme_name', 'BD-N' ) .' - '.esc_html__( 'Newsletter', 'baghdad-news' ) , $widget_ops );
		}

		/**
		 * Outputs the content for the widget instance.
		 */
		public function widget( $args, $instance ){

			/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
			$instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

			$text = isset( $instance['text'] ) ? $instance['text'] : '';

			# WPML
			$text = apply_filters( 'wpml_translate_single_string', $text, 'BD-N', 'widget_content_'.$this->id );

			echo ( $args['before_widget'] );


			# Title
			if ( ! empty($instance['title']) ){
				echo ( $args['before_title'] . $instance['title'] . $args['after_title'] );
			}

			?>

			<div class="widget-inner-wrap">

				<?php

					# Show Icon
					if( ! empty( $instance['show_icon'] )){ ?>
						<span class="fa fa-envelope newsletter-icon" aria-hidden="true"></span>
						<?php
					}

					# Text
					if( ! empty( $text ) ){ ?>
						<div class="subscribe-widget-content">
							<?php echo do_shortcode( $text ) ?>
						</div>
						<?php
					}

					if( ! empty( $instance['feedburner'] )){ ?>

						<form action="https://feedburner.google.com/fb/a/mailverify" method="post" class="subscribe-form" target="popupwindow" onsubmit="window.open('https://feedburner.google.com/fb/a/mailverify?uri=<?php echo esc_attr( $instance['feedburner'] ); ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
							<label class="screen-reader-text" for="email"><?php esc_html_e( 'Enter your Email address', 'baghdad-news' ); ?></label>
							<input class="subscribe-input required email" type="text" id="email" name="email" placeholder="<?php esc_html_e( 'Enter your Email address', 'baghdad-news' ); ?>">
							<input type="hidden" value="<?php echo esc_attr( $instance['feedburner'] ); ?>" name="uri">
							<input type="hidden" name="loc" value="en_US">
							<input class="button subscribe-submit" type="submit" name="submit" value="<?php esc_html_e( 'Subscribe', 'baghdad-news' ) ; ?>">
						</form>
						<?php
					}

					elseif( ! empty( $instance['mailchimp'] )){ ?>
						<div id="mc_embed_signup-<?php echo esc_attr( $args['widget_id'] ) ?>">
							<form action="<?php echo esc_attr( $instance['mailchimp'] ) ?>" method="post" id="mc-embedded-subscribe-form-<?php echo esc_attr( $args['widget_id'] ) ?>" name="mc-embedded-subscribe-form" class="subscribe-form validate" target="_blank" novalidate>
									<div class="mc-field-group">
										<label class="screen-reader-text" for="mce-EMAIL-<?php echo esc_attr( $args['widget_id'] ) ?>"><?php esc_html_e( 'Enter your Email address', 'baghdad-news' ); ?></label>
										<input type="email" value="" id="mce-EMAIL-<?php echo esc_attr( $args['widget_id'] ) ?>" placeholder="<?php esc_html_e( 'Enter your Email address', 'baghdad-news' ); ?>" name="EMAIL" class="subscribe-input required email">
									</div>
									<input type="submit" value="<?php esc_html_e( 'Subscribe', 'baghdad-news' ) ; ?>" name="subscribe" class="button subscribe-submit">
							</form>
						</div>
						<?php
					}

				?>

			</div><!-- .widget-inner-wrap /-->

			<?php

			echo ( $args['after_widget'] );
		}

		/**
		 * Handles updating settings for widget instance.
		 */
		public function update( $new_instance, $old_instance ){
			$instance               = $old_instance;
			$instance['title']      = sanitize_text_field( $new_instance['title'] );
			$instance['text']       = $new_instance['text'];
			$instance['show_icon']  = $new_instance['show_icon'];
			$instance['mailchimp']  = $new_instance['mailchimp'];
			$instance['feedburner'] = $new_instance['feedburner'];

			# WPML
			do_action( 'wpml_register_single_string', BG_NLABS_THEME_SLUG, 'widget_content_'.$this->id, $new_instance['text'] );

			return $instance;
		}

		/**
		 * Outputs the settings form for the widget.
		 */
		public function form( $instance ){
			$defaults = array(
				'title' => esc_html__( 'Newsletter', 'baghdad-news'),
				'text'  => '
	 <h4>'.esc_html__('Always stay with us.', 'baghdad-news' ).'</h4>
	 <h3>'.esc_html__('Subscribe to our mailing list to get the new updates!', 'baghdad-news' ).'</h3>
	 <p>'.esc_html__('Subscribe to our website`s mailing list to get the latest news first.', 'baghdad-news' ).'</p>'
			);

			$instance = wp_parse_args( (array) $instance, $defaults );

			$title      = isset( $instance['title'] ) ? $instance['title'] : '';
			$feedburner = isset( $instance['feedburner'] ) ? $instance['feedburner'] : '';
			$mailchimp  = isset( $instance['mailchimp'] ) ? $instance['mailchimp'] : '';
			$text       = isset( $instance['text'] ) ? $instance['text'] : '';
			$show_icon  = isset( $instance['show_icon'] ) ? 'true' : '';


			?>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'baghdad-news') ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>" class="widefat" type="text" />
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>"><?php esc_html_e( 'Text above the Email input field', 'baghdad-news') ?></label>
				<textarea rows="3" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>" class="widefat" ><?php echo esc_textarea( $text ) ?></textarea>
				<small><?php esc_html_e( 'Supports: Text, HTML and Shortcodes.', 'baghdad-news') ?></small>
			</p>

			<p>
				<input id="<?php echo esc_attr( $this->get_field_id( 'show_icon' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_icon' ) ); ?>" value="true" <?php checked( $show_icon, 'true' ); ?> type="checkbox" />
				<label for="<?php echo esc_attr( $this->get_field_id( 'show_icon' ) ); ?>"><?php esc_html_e( 'Show the icon?', 'baghdad-news') ?></label>
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'mailchimp' ) ); ?>"><?php esc_html_e( 'MailChimp Form Action URL', 'baghdad-news') ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'mailchimp' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'mailchimp' ) ); ?>" value="<?php echo esc_attr( $mailchimp ); ?>" class="widefat" type="text" />
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'feedburner' ) ); ?>"><strong><?php esc_html_e( '- OR -', 'baghdad-news') ?></strong> <?php esc_html_e( 'Feedburner ID', 'baghdad-news') ?></label>
				<input id="<?php echo esc_attr( $this->get_field_id( 'feedburner' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'feedburner' ) ); ?>" value="<?php echo esc_attr( $feedburner ); ?>" class="widefat" type="text" />
			</p>

		<?php
		}
	}



	/**
	 * Register the widget.
	 */
	add_action( 'widgets_init', 'BG_N_newsletter_widget_register' );
	function BG_N_newsletter_widget_register(){

		register_widget( 'BG_N_NEWSLETTER_WIDGET' );
	}

}
