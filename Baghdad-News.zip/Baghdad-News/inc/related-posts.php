<?php $related_posts = baghdad_news_related_posts_function(); ?>

<?php if ( $related_posts->have_posts()): ?>
<section class="bost-box-single">
    <div class="tapes-title">
	    <h3 >
	    	<i class="fa fa-thumbs-up"></i>
			<span><?php _e( 'You May Also Like', 'baghdad-news' ); ?></span>
	    </h3>
        <div class="stripe-line"></div>
    </div>

	<div class="related-posts clearfix">

		<?php while ( $related_posts->have_posts() ) : $related_posts->the_post(); ?>
			<div class="single-related-posts">

				<?php if ( has_post_thumbnail() ): ?>
					<div class="related-posts-thumbnail">
						<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
							<?php the_post_thumbnail( 'baghdad-news-featured-post-medium' ); ?>
						</a>
					</div>
				<?php endif; ?>

				<div class="article-content">

					<h3 class="entry-title">
						<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a>
					</h3><!--/.post-title-->

					<div class="below-entry-meta">

                            <span id="posts-box-user-icon" class="Coding-icon l">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </span>
    
    
                            <span id="posts-box-user-text" class="posts-box-footer-data ">
                               <?php the_author_posts_link();?>
                               
                            </span>
                            <span id="posts-box-time-icon" class="Coding-icon " title="وقت نشر المقالة">
                                <i class="fa fa-clock-o" aria-hidden="true"></i>
                            </span>
                       
                            <span id="posts-box-time-text" class="posts-box-footer-data " title="وقت نشر المقالة">
                                <?php the_date();?>
                            </span>

                            <span id="posts-box-comment-icon" class="Coding-icon">
                                <a href="<?php the_permalink(); ?>#comments" title="<?php _e( 'Go to the post`s comments &raquo;', 'baghdad-news' ); ?>">
                                    <i class="fa fa-comments"></i>
                                </a>
                            </span>

                            <span id="posts-box-comment-text" class=" posts-box-comment-text">
                                <a href="<?php the_permalink(); ?>#comments" title="<?php _e( 'Go to the post`s comments &raquo;', 'baghdad-news' ); ?>">
                                    <?php comments_number( '0', '1', '%' ); ?>
                                </a>
                            </span>
						
					</div>

				</div>

			</div><!--/.related-->
		<?php endwhile; ?>

    </div><!--/.post-related-->

<?php endif; ?>

<?php wp_reset_postdata(); ?>
</section>
