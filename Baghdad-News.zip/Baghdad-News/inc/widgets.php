<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

/*
@package baghdad-news

    ===============================
    WIDGET GETING
    ===============================

*/


 require get_template_directory() . '/inc/widgets/facebook.php';
 require get_template_directory() . '/inc/widgets/ads.php';
 require get_template_directory() . '/inc/widgets/newsletter.php';
 require get_template_directory() . '/inc/widgets/widget-post-3.php';
 require get_template_directory() . '/inc/widgets/widget-posts.php';
 require get_template_directory() . '/inc/widgets/widget-slider-posts.php';
 require get_template_directory() . '/inc/widgets/youtube.php';
?>