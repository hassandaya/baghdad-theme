<?php get_header();?>
<?php
$baghdad_news_header_slider_category  = esc_attr( get_theme_mod( 'baghdad_news_header_slider_category', 'all' ) );
$baghdad_news_header_slider_max_posts = esc_attr( get_theme_mod( 'baghdad_news_header_slider_max_posts', '6' ) );
$baghdad_news4_fullwidth      = get_theme_mod( 'baghdad_news4_fullwidth', false );
$baghdad_news_header_slider_disable   = (bool) get_theme_mod( 'baghdad_news_header_slider_disable', false );
$baghdad_news_header_slider_random    = (bool) get_theme_mod( 'baghdad_news_header_slider_random', false );
$baghdad_news4_disable        = (bool) get_theme_mod( 'baghdad_news4_disable', false );
the_post();$category      = get_the_category();
// 
$Advertisement_before_archive_url  =  get_theme_mod( 'baghdad_news_Advertisement_before_archive_url' );
$Advertisement_before_archive_img  =  get_theme_mod( 'baghdad_news_Advertisement_before_archive_img' );
$Advertisement_before_archive_code =  get_theme_mod( 'baghdad_news_Advertisement_before_archive_Code' );

?>

<div class="div-container div-division"> <!------ok----->
	
    <!-- banner slider start -->
    <div class="outerbox">
        <div id="outerbox-box">
        <?php
			    $archive_content_classes = apply_filters( 'baghdad_news_archive_content_classes', array( 'baghdad_news-content-left', 'col-md-9' ) );
			?>
			<div 
			<?php
			if ( ! empty( $archive_content_classes ) ) {
				echo 'class="' . implode( ' ', $archive_content_classes ) . '"'; }
			?>
            >
                <?php
                

				/* ---------Section 2--------- */
				if ( ! $baghdad_news4_fullwidth && ! $baghdad_news4_disable ) {
					baghdad_news_display_section( 4 );
				}

        ?>
        </div>
        </div>
    </div>
    <!-- banner slider end   -->
    
    <!----div.post-start--------->
    <div class="hassan">
    <div id="side" class="post-side content sidebar-wrapper">




    
        <?php if ( ! empty( $Advertisement_before_archive_code ) ) { 
               echo  '<div class="Advertisement-article-footer adds">'.$Advertisement_before_archive_code.'</div>'; 
           
            }
            

            else {
                if ( ! empty( $Advertisement_before_archive_img ) ) {
                    echo '<div class="Advertisement-article-footer adds">
                              <a href="'.$Advertisement_before_archive_url.'" target="_blank">
                                  <img src="'.$Advertisement_before_archive_img.'" />
                              </a>
                          </div>';
                }
            }
            
            

        ?>
        <div class="div-content ">
        
            <?php if (have_posts()):?><div class="box-style">
                <div class="time-line-yare"><?php  echo get_the_date( ' Y' ); ?></div>
                <?php while (have_posts()):?>
                    <?php the_post();?>
                    
                    <!--------post box code start--------->
    
                    <section  class="bost-box"> 
                        <div class="time-line-moon">
                           <?php echo get_the_date( 'j , F' ); ?>
                        </div>
                        <!------seaction-img.start-------->
                        <div class="bost-box-img ">
                            <!-- post category -->
                            <a href="<?php echo esc_url( get_category_link( $category[0]->cat_ID ) ); ?>" class="category-block"
								title="<?php esc_html_e( 'Category', 'baghdad-news' ); ?> <?php echo esc_attr( $category[0]->cat_name ); ?>">
								<?php echo esc_attr( $category[0]->cat_name ); ?>
                            </a>
                            
                            
                            <!-- post support start-->
                           <a href="<?php the_permalink()?>">
                            <?php if(has_post_thumbnail()):?>
                                     <?php echo covernews_post_format($post->ID); ?>
                                     <?php the_post_thumbnail( 'large', true );?>

                            <?php else:?>
                                
                                <?php echo '<div class="no-featuer-img"><img src="' . esc_url( get_theme_mod('dosislite_nav_logo_url') ) . '" /></div>'; ?>
                                
                            <?php endif?>
                            </a>
                        </div>
                        <!------seaction-img.end..-------->

                        <!------seaction-header.start----->
                        <header class="bost-box-header " >
                            <h3>
                                <a href="<?php the_permalink()?>">
                                    <?php the_title();?>
                                </a>
                            </h3>    
                        </header>
                        <!------seaction-header.end------->
           



               


                        <!----div-footer.start--------->
                        <footer class="bost-box-footer ">
                            <span id="posts-box-user-icon" class="Coding-icon l">
                                <i class="fa fa-user" aria-hidden="true"></i>
                            </span>
    
    
                            <span id="posts-box-user-text" class="posts-box-footer-data ">
                               <?php the_author_posts_link();?>
                               
                            </span>
                            <span id="posts-box-time-icon" class="Coding-icon " title="وقت نشر المقالة">
                                <i class="fa fa-clock-o" aria-hidden="true"></i>
                            </span>
                       
                            <span id="posts-box-time-text" class="posts-box-footer-data " title="وقت نشر المقالة">
                                <time datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished"><?php echo get_the_date(); ?></time>
                            </span>

                            <span id="posts-box-comment-icon" class="Coding-icon">
                                <a href="<?php the_permalink(); ?>#comments" title="<?php _e( 'Go to the post`s comments &raquo;', 'baghdad-news' ); ?>">
                                    <i class="fa fa-comments"></i>
                                </a>
                            </span>

                            <span id="posts-box-comment-text" class=" posts-box-comment-text">
                                <a href="<?php the_permalink(); ?>#comments" title="<?php _e( 'Go to the post`s comments &raquo;', 'baghdad-news' ); ?>">
                                    <?php comments_number( '0', '1', '%' ); ?>
                                </a>
                            </span>
                        </footer>
                        <!----div-footer.end..--------->

                        <!----div-article.start-------->
                        <article class="bost-box-text ">
                                <?php the_excerpt();?>
                        </article>
                        <!----div-article.end..-------->
                    </section>

                    <!--------post box code end --------->
                <?php endwhile; ?></div>
            <?php else: ?>
                <style>
                        .box-style{
                            display: block;
                            padding: 0;
                        }

                    </style>
                <div class="main-content tie-col-md-8 tie-col-xs-12" role="main">

		
                    <header class="entry-header-outer container-wrapper">
                    	<h1 class="page-title">لم يتم العثور على نتائج</h1>
                    </header><!-- .entry-header-outer /-->

                    <div class="mag-box not-found">
                    	<div class="container-wrapper">
                    
                    		
                            <h5>يبدوا أننا لم ’ نستطيع أن نجد المحتوى ’الذي تبحث عنه. من الممكن أن البحث يفيدك.</h5>

                            <form role="search" method="get" id="searchform" class="search-form" action="<?php echo get_home_url(); ?>">               
                    		    <label>
                                    <input class="search-field"type="text" placeholder="search form"  name="s" di="s" id="search" value="<?php the_search_query(); ?>">
                                </label>
                                
                                <input class="search-submit" type="submit" id="searchsubmit" value="بحث">
                        	</form>
                    		
                    	</div><!-- .container-wrapper /-->
                    </div><!-- .mag-box /-->

	            </div>
            <?php endif;?>
            
            <!-- pagination -->
            <?php get_template_part('pagination');?>
        </div>
    </div>

   <?php get_sidebar();?>
   <?php get_footer();?>
