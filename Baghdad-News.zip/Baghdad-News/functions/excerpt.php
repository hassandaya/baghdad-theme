<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */



//  excerpt code  

    //  هذا نمودج الاول 

    function wpdocs_excerpt_more( $more ) {
        return '... <div class="show-more">
                        <a href="'.get_the_permalink().'">
                        '.esc_html__( 'Read More &raquo;', 'baghdad-news' ).'
                        </a>
                   </div>';
    }
    add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );

    // نمودج الثاني 

    /**
     * Filter the except length to 20 words.
     *
     * @param int $length Excerpt length.
     * @return int (Maybe) modified excerpt length.
     */
    function wpdocs_custom_excerpt_length( $length ) {
        return 25 ;
    }
    add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 111 );


// theme support 

add_theme_support('post-thumbnails');
