<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

 

//  custome header back img
add_theme_support('custom-header',apply_filters('wp_custom_header_args', array(
    'default-image' => '',
    'width' => 1900,
    'height' => 600,
    'flex-height' => true,
    'flex-width' => true,
)));



// Add user contact methods
add_filter( 'user_contactmethods','wpse_user_contactmethods', 10, 1 );
function wpse_user_contactmethods( $contact_methods ) {
    $contact_methods['facebook'] = __( 'Facebook URL', 'text_domain' );
    $contact_methods['twitter']  = __( 'Twitter URL', 'text_domain' );
    $contact_methods['instagram'] = __( 'Instagram URL', 'text_domain');
    $contact_methods['youtube']  = __( 'YouTube URL', 'text_domain' );

    return $contact_methods;
}

// languages
function baghdad_news_load_theme_textdomain() {
    load_theme_textdomain( 'baghdad-news', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'baghdad_news_load_theme_textdomain' );




/**
 * Filter the front page template so it's bypassed entirely if the user selects
 * to display blog posts on their homepage instead of a static page.
 */
function baghdad_news_filter_front_page_template( $template ) {
	$baghdad_news_keep_old_fp_template = get_theme_mod( 'baghdad_news_keep_old_fp_template' );
	if ( ! $baghdad_news_keep_old_fp_template ) {
		return is_home() ? '' : $template;
	} else {
		return '';
	}
}
add_filter( 'frontpage_template', 'baghdad_news_filter_front_page_template' );



// all nav lise code
register_nav_menus(array(
    // top menu
    'header' => esc_html__( 'top nav', 'baghdad-news' )  ,

    // main menu
    'main-menu' => esc_html__( 'main menu', 'baghdad-news' )  ,
));






/*---------------------------------------------------------------------------*/
# Add user's social accounts
/*-----------------------------------------------------------------------------------*/
add_action( 'show_user_profile', 'baghdad_news_show_extra_profile_fields' );
add_action( 'edit_user_profile', 'baghdad_news_show_extra_profile_fields' );
function baghdad_news_show_extra_profile_fields( $user ) {
	wp_enqueue_media();
?>
	<h3><?php _e( 'Cover Image', 'baghdad-news' ) ?></h3>
	<table class="form-table">
		<tr>
			<th><label for="author-cover-img"><?php _e( 'Cover Image', 'baghdad-news' ) ?></label></th>
			<td>

                <?php $author_cover_img = get_the_author_meta( 'author-cover-img', $user->ID ) ; ?>
				<input id="author-cover-img" class="img-path" type="text" size="56" style="direction:ltr; text-laign:left" name="author-cover-img" value="<?php echo esc_attr( get_the_author_meta( 'author-cover-img', $user->ID ) ); ?>" />
				<input id="upload_author-cover-img_button" type="button" class="button" value="<?php _e( 'Upload', 'baghdad-news' ) ?>" />

				<div class="author-cover-preview" style=" max-width: 500px; height: auto; margin: 10px 5px; ">
					<img style="     width: 100%; object-fit: cover;" src="<?php echo esc_attr( get_the_author_meta( 'author-cover-img', $user->ID ) ); ?>" alt="" />
				</div>


                <?php
                wp_enqueue_script('jquery');
                wp_enqueue_media();
                ?>

                <script type="text/javascript">
                    jQuery(document).ready(function($){
                          $('#upload_author-cover-img_button').click(function(e) {
                                 e.preventDefault();
                                 var image = wp.media({ 
                                 title: 'Upload Image',
                                 multiple: false
                          }).open()
                          .on('select', function(e){
                         var uploaded_image = image.state().get('selection').first();
                         console.log(uploaded_image);
                         var image_url = uploaded_image.toJSON().url;
                         $('#author-cover-img').val(image_url);
                            });
                        });
                    });
                </script>
			</td>
		</tr>
    </table>
    

    <!--  -->

    <h3><?php _e( 'Author Location', 'baghdad-news' ) ?></h3>
	<table class="form-table">
		<tr>
			<th><label for="author-Location"><?php _e( 'Enter Author Location', 'baghdad-news' ) ?></label></th>
			<td>

                <?php $author_cover_img = get_the_author_meta( 'author-Location', $user->ID ) ; ?>
				<input id="author-Location" class="img-path" type="text" size="56" style="direction:ltr; text-laign:left" name="author-Location" value="<?php echo esc_attr( get_the_author_meta( 'author-Location', $user->ID ) ); ?>" />


                <?php
                wp_enqueue_script('jquery');
                wp_enqueue_media();
                ?>

                <script type="text/javascript">
                    jQuery(document).ready(function($){
                          $('#upload_author-Location_button').click(function(e) {
                                 e.preventDefault();
                                 var image = wp.media({ 
                                 title: 'Upload Image',
                                 multiple: false
                          }).open()
                          .on('select', function(e){
                         var uploaded_image = image.state().get('selection').first();
                         console.log(uploaded_image);
                         var image_url = uploaded_image.toJSON().url;
                         $('#author-Location').val(image_url);
                            });
                        });
                    });
                </script>
			</td>
		</tr>
	</table>


	
<?php }

## Save user's social accounts
add_action( 'personal_options_update', 'baghdad_news_save_extra_profile_fields' );
add_action( 'edit_user_profile_update', 'baghdad_news_save_extra_profile_fields' );
function baghdad_news_save_extra_profile_fields( $user_id ) {
	if ( !current_user_can( 'edit_user', $user_id ) ) return false;
    update_user_meta( $user_id, 'author-cover-img', 			$_POST['author-cover-img'] );
    update_user_meta( $user_id, 'author-Location', 			$_POST['author-Location'] );
}


function ben_getPostViews($postID){
    $count_key = 'get_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "";
    }
    return '' .$count;
}
function ben_setPostViews($postID) {
    $count_key = 'get_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);



/**************************************************************************************/

/*
 * Category Color for widgets and other
 */
if ( ! function_exists( 'baghdad_news_colored_category' ) ) :
	function baghdad_news_colored_category() {
		global $post;
		$categories = get_the_category();
		$separator  = '&nbsp;';
		$output     = '';
		if ( $categories ) {
			$output .= '<div class="above-entry-meta"><span class="cat-links">';
			foreach ( $categories as $category ) {
				$color_code = baghdad_news_category_color( get_cat_id( $category->cat_name ) );
				if ( ! empty( $color_code ) ) {
					$output .= '<a href="' . get_category_link( $category->term_id ) . '" style="background:' . baghdad_news_category_color( get_cat_id( $category->cat_name ) ) . '" rel="category tag">' . $category->cat_name . '</a>' . $separator;
				} else {
					$output .= '<a href="' . get_category_link( $category->term_id ) . '"  rel="category tag">' . $category->cat_name . '</a>' . $separator;
				}
			}
			$output .= '</span></div>';
			echo trim( $output, $separator );
		}
	}
endif;

/**************************************************************************************/


/**************************************************************************************/

/*
 * Category Color Options
 */
if ( ! function_exists( 'baghdad_news_category_color' ) ) :
	function baghdad_news_category_color( $wp_category_id ) {
		$args     = array(
			'orderby'    => 'id',
			'hide_empty' => 0,
		);
		$category = get_categories( $args );
		foreach ( $category as $category_list ) {
			$color = get_theme_mod( 'baghdad_news_category_color_' . $wp_category_id );

			return $color;
		}
	}
endif;

/**************************************************************************************/


/**************************************************************************************/



function sb_simple_ads_posts( $content ) {
    $Advertisement_before_url  =  get_theme_mod( 'baghdad_news_Advertisement_before_article_url' );
	$Advertisement_before_img  =  get_theme_mod( 'baghdad_news_Advertisement_before_article_img' );
	$Advertisement_before_code =  get_theme_mod( 'baghdad_news_Advertisement_before_article_Code' );
	if ( ! empty( $Advertisement_before_code ) ){
		$Advertisement_before_son_out = '<div class="Advertisement_before_article Advertisement_article adds">'.$Advertisement_before_code.'</div>';
	} else {
		if ( ! empty( $Advertisement_before_img ) ){
			$Advertisement_before_son_out    = '<div class="Advertisement_before_article Advertisement_article adds"><a href="'.$Advertisement_before_url.'" target="_blank"><img src="'.$Advertisement_before_img.'" /></a></div>' ;
		} 
		else{
			echo '';
		}
		
	}

	$Advertisement_after_url  =  get_theme_mod( 'baghdad_news_Advertisement_after_article_url' );
	$Advertisement_after_img  =  get_theme_mod( 'baghdad_news_Advertisement_after_article_img' );
	$Advertisement_after_code =  get_theme_mod( 'baghdad_news_Advertisement_after_article_Code' );
	if ( ! empty( $Advertisement_after_code ) ){
		$Advertisement_after_son_out = '<div class="Advertisement_after_article Advertisement_article adds">'.$Advertisement_after_code.'</div>';
	} else {
		if ( ! empty( $Advertisement_after_img ) ){
			$Advertisement_after_son_out    = '<div class="Advertisement_after_article Advertisement_article adds"><a href="'.$Advertisement_after_url.'" target="_blank"><img src="'.$Advertisement_after_img.'" /></a></div>' ;
		} 
		else{
			echo '';
		}
		
	}

	if ( is_singular( 'post' ) ) {
		$Advertisement_before_ads_code = $Advertisement_before_son_out;
		$Advertisement_after_ads_code = $Advertisement_after_son_out;
		$content = $Advertisement_before_ads_code . $content . $Advertisement_after_ads_code;
	}
	

	return $content;
}

add_filter( 'the_content', 'sb_simple_ads_posts' );