<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


// Output Customize Color Css

function learningWordPress_custoize_css(){
    $back_color   = get_theme_mod ('lwp_back_color');
    $window_color = get_theme_mod ('lwp_window_color');
    $cover_color = get_theme_mod ('lwp_cover_color');
    $navMenu_color = get_theme_mod ('lwp_navMenu_color');
    $tapes_color  = get_theme_mod ('lwp_tapes_color');
    $text_link_color   = get_theme_mod ('lwp_text_link_color');
    $normal_text_color = get_theme_mod ('lwp_normal_text_color');
    $info_color = get_theme_mod ('lwp_info_color');
    $img_outline_color = get_theme_mod ('lwp_outline_img_color');
    $Mobile_Menu_color = get_theme_mod ('Mobile_Menu_color');
    $mobile_header_bg = get_theme_mod ('baghdad_news_Mobile_mobile_header_bg_st');
    $main_aree_mobile_back_color = get_theme_mod ('main_aree_mobile_back_color');
    $baghdad_news_mobile_icon_menu_bg_st = get_theme_mod ('baghdad_news_mobile_icon_menu_bg_st');
    $baghdad_news_mobile_icon_menu_color_st = get_theme_mod ('baghdad_news_mobile_icon_menu_color_st');
    $baghdad_news_footer_Background = get_theme_mod ('baghdad_news_footer_Background');
    $baghdad_news_footer_titile_color = get_theme_mod ('baghdad_news_footer_titile_color');
    $baghdad_news_footer_link_color = get_theme_mod ('baghdad_news_footer_link_color');
    $baghdad_news_footer_text_color = get_theme_mod ('baghdad_news_footer_text_color');
    $baghdad_news_Copyrights_text_color = get_theme_mod ('baghdad_news_Copyrights_text_color');
    $baghdad_news_Copyrights_Background_color = get_theme_mod ('baghdad_news_Copyrights_Background_color');
    $lwp_Header_background = get_theme_mod ('lwp_Header_background');
    // dark
    $back_dark_color   = get_theme_mod ('lwp_back_dark_color');
    $window_dark_color = get_theme_mod ('lwp_window_dark_color');
    $cover_dark_color = get_theme_mod ('lwp_cover_dark_color');
    $navMenu_dark_color = get_theme_mod ('lwp_navMenu_dark_color');
    $text_link_dark_color   = get_theme_mod ('lwp_text_link_dark_color');
    $normal_dark_text_color = get_theme_mod ('lwp_normal_dark_text_color');
    $dark_info_color = get_theme_mod ('lwp_dark_info_color');
    $mobile_header_bg_dark = get_theme_mod ('baghdad_news_Mobile_mobile_header_bg_dark_st');
    $main_aree_mobile_back_color_dark = get_theme_mod ('main_aree_mobile_back_color_dark');
    $baghdad_news_mobile_icon_menu_bg_dark_st = get_theme_mod ('baghdad_news_mobile_icon_menu_bg_dark_st');
    $baghdad_news_mobile_icon_menu_color_dark_st = get_theme_mod ('baghdad_news_mobile_icon_menu_color_dark_st');
    $lwp_dark_Header_background = get_theme_mod ('lwp_dark_Header_background');

    echo '
    <meta name="theme-color" content='.$tapes_color.'>
    <style>
      html{
        --header-cover-color:'.$lwp_Header_background.';
        --back-color:'.$back_color.';
        --window-color:'.$window_color.';
        --cover-color:'.$cover_color.';
        --main-nav-bg:'.$navMenu_color.';
        --tapes-color:'.$tapes_color.';
        --text-link-colo:'.$text_link_color.';
        --normal-text-color:'.$normal_text_color.';
        --info-color:'.$info_color.';
        --img-outline-color:'.$img_outline_color.';
        --Mobile-Menu-color:'.$Mobile_Menu_color.';
        --mobile-header-bg:'.$mobile_header_bg.';
        --mobile-main-aree-bg:'.$main_aree_mobile_back_color.';
        --mobile-icon-menu-bg:'.$baghdad_news_mobile_icon_menu_bg_st.';
        --mobile-icon-menu-color:'.$baghdad_news_mobile_icon_menu_color_st.';
        --footer-bg:'.$baghdad_news_footer_Background.';
        --footer-title-color:'.$baghdad_news_footer_titile_color.';
        --footer-link-color:'.$baghdad_news_footer_link_color.';
        --footer-text-color:'.$baghdad_news_footer_text_color.';
        --Copyrights-color:'.$baghdad_news_Copyrights_text_color.';
        --Copyrights-background:'.$baghdad_news_Copyrights_Background_color.';
    }
    </style>
    <style>
    .html-dark{
        --header-cover-color:'.$lwp_dark_Header_background.';
        --back-color:'.$back_dark_color.';
        --window-color:'.$window_dark_color.';
        --cover-color:'.$cover_dark_color.';
        --main-nav-bg:'.$navMenu_dark_color.';
        --text-link-colo:'.$text_link_dark_color.';
        --normal-text-color:'.$normal_dark_text_color.';
        --info-color:'.$dark_info_color.';
        --mobile-header-bg:'.$mobile_header_bg_dark.';
        --mobile-main-aree-bg:'.$main_aree_mobile_back_color_dark.';
        --mobile-icon-menu-bg:'.$baghdad_news_mobile_icon_menu_bg_dark_st.';
        --mobile-icon-menu-color:'.$baghdad_news_mobile_icon_menu_color_dark_st.';
    }
    </style>
    ';
}
add_action('wp_head', 'learningWordPress_custoize_css');