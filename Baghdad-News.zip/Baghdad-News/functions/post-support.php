<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


if (!function_exists('covernews_setup')):
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
		/**
		 *
		 */
		/**
		 *
		 */
		function covernews_setup() {
	        /*
             * Enable support for Post Formats on posts and pages.
             *
             * @link https://developer.wordpress.org/themes/functionality/post-formats/
            */
            add_theme_support( 'post-formats', array( 'image', 'video', 'gallery','audio' ) );
		}
endif;
add_action('after_setup_theme', 'covernews_setup');


/**
 * Returns no image url.
 *
 * @since  CoverNews 1.0.0
 */
if (!function_exists('covernews_post_format')):
    function covernews_post_format($post_id)
    {
        $post_format = get_post_format($post_id);
        switch ($post_format) {
            case "image":
                echo "<div class='em-post-format'><i class='fa fa-image'></i></div>";
                break;
            case "video":
                echo "<div class='em-post-format'><span class='post-format-video'></span></div>";

                break;
            case "gallery":
                echo "<div class='em-post-format'><i class='post-format-photo-video'></i></div>";
                break;
            case "audio":
                echo "<div class='em-post-format'><i class='fa fa-volume-up'></i></div>";
                break;
            default:
                echo "";
        }


    }

endif;