<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */





function diya_enqueue_stylesheets(){
    wp_enqueue_style('diya_stylesheet',get_stylesheet_uri());
    wp_style_add_data('diya_stylesheet', 'rtl', 'replace');
    // slider style shet
    wp_enqueue_style('banner-slider-stule-1', get_template_directory_uri().'/css/slider.css');
    wp_enqueue_style('banner-slider-stule-2', get_template_directory_uri().'/css/lightslider'.$min.'.css');
    // screen withe 
    wp_enqueue_style('screen-withe', get_template_directory_uri().'/css/screen-withe'.$min.'.css');
    // post-box-style
    wp_enqueue_style('post-box-style', get_template_directory_uri().'/css/post-box-style'.$min.'.css');
    //related-posts
    wp_enqueue_style('related-posts', get_template_directory_uri().'/css/related-posts'.$min.'.css');
    //news-ticker
    wp_enqueue_style('news-ticker', get_template_directory_uri().'/css/news-ticker'.$min.'.css');
    //all-style
    wp_enqueue_style('all-style', get_template_directory_uri().'/css/all-style'.$min.'.css');
    //post-format
    wp_enqueue_style('post-format', get_template_directory_uri().'/css/post-format'.$min.'.css');
    //comment
    wp_enqueue_style('comment', get_template_directory_uri().'/css/comment'.$min.'.css');
    // social style
    wp_enqueue_style('social-style', get_template_directory_uri().'/css/social-style'.$min.'.css');
    // author style
    wp_enqueue_style('author', get_template_directory_uri().'/css/author'.$min.'.css');
    // banner-section-3 style
    wp_enqueue_style('banner-section-3', get_template_directory_uri().'/css/banner-section-3'.$min.'.css');
    //scss
    wp_enqueue_style('scss', get_template_directory_uri().'/css/css'.$min.'.scss');
    // widget-style
    wp_enqueue_style('widget-style', get_template_directory_uri().'/css/widget-style'.$min.'.css');
    // dark mode script
    wp_enqueue_script('dark-mode-js', get_template_directory_uri().'/js/dark-script.js', array(), '20151215', true);
    // wp script
    wp_enqueue_script('wp-script-js', get_template_directory_uri().'/js/wp-script.js', array(), '20151215', true);
    // header script
    wp_enqueue_script('header-script-js', get_template_directory_uri().'/js/header-script.js', array(), '20151215', true);
    // banner-section-3
    wp_enqueue_script('banner-section-3', get_template_directory_uri().'/js/banner-section-3.js', array(), '20151215', true);
    // sticky-sidebar
    wp_enqueue_script('sticky-sidebar', get_template_directory_uri().'/js/sticky-sidebar.js', array(), '20151215', true);
    wp_enqueue_script('banner-slider-js-2', get_template_directory_uri().'/js/banner/lightslider.js', array(), '20151215', true);
    wp_enqueue_script('banner-slider-js-3', get_template_directory_uri().'/js/banner/slider-banner.js', array(), '20151215', true);
}

add_action('wp_enqueue_scripts','diya_enqueue_stylesheets');
