<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

// body class
add_filter( 'body_class', 'wp_body_class' );
/**
 * Filter the body_class
 *
 * Throwing different body class for the different layouts in the body tag
 */
function wp_body_class( $classes ) { 
	// full or boxes wp screen
	if ( get_theme_mod( 'baghdad_news_select_site_layout', 'wide_layout' ) == 'wide_layout' ) {
		$classes[] = 'wide';
	} elseif ( get_theme_mod( 'baghdad_news_select_site_layout', 'wide_layout' ) == 'boxed_layout' ) {
		$classes[] = 'boxes';
	}
    // sidebar float
	if ( get_theme_mod( 'baghdad_news_select_blog_sidebar_position', 'sidebar-left' ) == 'sidebar-left' ) {
		$classes[] = 'sidebar-left';
	} elseif ( get_theme_mod( 'baghdad_news_select_blog_sidebar_position', 'sidebar-right' ) == 'sidebar-right' ) {
		$classes[] = 'sidebar-right';
	}


	// tapes title 
	if ( get_theme_mod( 'baghdad_news_select_tapes_title', 'one-option-title' ) == 'one-option-title' ) {
		$classes[] = 'one-title';
	} elseif ( get_theme_mod( 'baghdad_news_select_tapes_title', 'tow-option-title' ) == 'tow-option-title' ) {
		$classes[] = 'tow-title';
	}

	// box style options
	if ( get_theme_mod( 'baghdad_news_select_box_style', 'one-box-style' ) == 'one-box-style' ) {
		$classes[] = 'one-box-style';
	} elseif ( get_theme_mod( 'baghdad_news_select_box_style', 'tow-box-style' ) == 'tow-box-style' ) {
		$classes[] = 'tow-box-style';
	} elseif ( get_theme_mod( 'baghdad_news_select_box_style', 'three-box-style' ) == 'three-box-style' ) {
		$classes[] = 'three-box-style';
	} elseif ( get_theme_mod( 'baghdad_news_select_box_style', 'four-box-style' ) == 'four-box-style' ) {
		$classes[] = 'four-box-style';
	}elseif ( get_theme_mod( 'baghdad_news_select_box_style', 'five-box-style' ) == 'five-box-style' ) {
		$classes[] = 'five-box-style';
	}
	
	
	

	// box_shape options
	if ( get_theme_mod( 'baghdad_news_select_box_shape', 'outline-diagram' ) == 'outline-diagram' ) {
		$classes[] = 'outline-diagram';
	} elseif ( get_theme_mod( 'baghdad_news_select_box_shape', 'clean' ) == 'clean' ) {
		$classes[] = 'clean';
	}


	// outline img style 
	if ( get_theme_mod( 'baghdad_news_select_outline_img', 'img-outline-none' ) == 'img-outline-none' ) {
		$classes[] = '';
	} 
	
	elseif ( get_theme_mod( 'baghdad_news_select_outline_img', 'img-outline-1' ) == 'img-outline-1' ) {
		$classes[] = 'img-outline-1';
	} 
	
	elseif ( get_theme_mod( 'baghdad_news_select_outline_img', 'img-outline-2' ) == 'img-outline-2' ) {
		$classes[] = 'img-outline-2';
	}

	//loading style
	if ( get_theme_mod( 'baghdad_news_Loading', 'none-loadin-style' ) == 'none-loadin-style' ) {
		$classes[] = '';
	} 
	
	elseif ( get_theme_mod( 'baghdad_news_Loading', 'one-loadin-style' ) == 'one-loadin-style' ) {
		$classes[] = 'one-loadin-style';
	} 
	
	elseif ( get_theme_mod( 'baghdad_news_Loading', 'tow-loading-style' ) == 'tow-loading-style' ) {
		$classes[] = 'tow-loading-style';
	} 
	
	


	return $classes;
}