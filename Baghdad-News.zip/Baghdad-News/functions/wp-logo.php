<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

// web logo code


function simpletheme_custom_logo() {
    $defaults = array(
    'height'      => '180',
    'width'       => 'full',
    'flex-height' => true,
    'flex-width'  => true,
    'header-text' => array( 'site-title', 'site-description' ),
    );
    add_theme_support( 'custom-logo', array(
        'flex-width'  => true,
        'flex-height' => true,
    ) );
   }
   add_action( 'after_setup_theme', 'simpletheme_custom_logo' );
   