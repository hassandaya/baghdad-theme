<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


// theme widget code

function lwn_register_widgets(){
    // sade bar 
    $sidebar = array(
        'name'          =>  esc_html__( 'sidebar', 'baghdad-news' ) ,
        'id'            =>  'sidebar' ,
        'before_widget' =>  '<div id="%2$s" class="widget widget-side recent-posts-2 %2$s">' ,
        'after_widget'  =>  '</div>' ,
        'before_title'  =>  '<div class="tapes-title"><h3>' ,
        'after_title'   =>  '</h3><div class="stripe-line"></div></div>'
    );
    register_sidebar($sidebar);
    
    // footer widget 1
    
    $footer1 = array(
        'name'          =>  esc_html__( 'Footer Column 1', 'baghdad-news' )  ,
        'id'            =>  'footer1' ,
        'before_widget' =>  '<div id="%2$s" class="widget lwn-widget %2$s">' ,
        'after_widget'  =>  '</div>' ,
        'before_title'  =>  '<h4>' ,
        'after_title'   =>  '</h4>'
    );
    register_sidebar($footer1);

    // footer widget 2

    $footer2 = array(
        'name'          =>  esc_html__( 'Footer Column 2', 'baghdad-news' )  ,
        'id'            =>  'footer2' ,
        'before_widget' =>  '<div id="%2$s" class="widget lwn-widget %2$s">' ,
        'after_widget'  =>  '</div>' ,
        'before_title'  =>  '<h4>' ,
        'after_title'   =>  '</h4>'
    );
    register_sidebar($footer2);

}

add_action('widgets_init' , 'lwn_register_widgets');