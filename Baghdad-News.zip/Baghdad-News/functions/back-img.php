<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


// back img
$another_args = array(
    'default-color'      => '',
    'default-image'      => get_template_directory_uri() . '/photo/body-bg.png',
    'default-position'   => 'center',
    'default-repeat'     => 'repeat',     
);
add_theme_support( 'custom-background', $another_args );