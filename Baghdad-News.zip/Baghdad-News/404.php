<?php get_header();?>


	 <div class="div-container div-division"> <!------ok----->
	
    
    <!----div.post-start--------->
    <div class="side-404">
    <div class="content-404 ">
            <div class="main-content tie-col-md-8 tie-col-xs-12" role="main">

	
                <header class="entry-header-outer container-wrapper font-404">
					<h2> <i class="fa fa-frown-o"></i> <br>404 <br>
					<h3>المعذرة، هذه الصفحة غير موجودة.</h3>
				</h2>
                </header><!-- .entry-header-outer /-->

                <div class="mag-box not-found found-404">
                	<div class="container-wrapper">
                    
                		
                        <h5>يبدوا أننا لم ’ نستطيع أن نجد المحتوى ’الذي تبحث عنه. من الممكن أن البحث يفيدك.</h5>

                        <form role="search" method="get" id="searchform" class="search-form" action="<?php echo get_home_url(); ?>">                    
                		    <label>
                                <input class="search-field field-404"type="text" placeholder="search form"  name="s" di="s" id="search" value="<?php the_search_query(); ?>">
                            </label>
                            
                                <input class="search-submit submit-404" type="submit" id="searchsubmit" value="بحث">
                    	</form>
                		
                 	</div><!-- .container-wrapper /-->
                </div><!-- .mag-box /-->

	        </div>
        </div>
		</div>
		
		</div>
   <!-----aside-end..-------->
</div>
<!-------div.body-end..------->
   <?php get_footer();?>
