<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


$wp_query = new WP_Query(
	array(
		'posts_per_page'      => 5,
		'order'               => 'DESC',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'category_name'       => ( $baghdad_news_category != 'all' ? $baghdad_news_category : '' ),
	)
);?>

<?php
	if ( ! empty( $baghdad_news_title ) ) {
?>
	<div class="tapes-title window-color">
		<h3><?php echo esc_attr( $baghdad_news_title ); ?></h3>
		<div class="stripe-line"></div>
	</div>
	<?php
} else {
	if ( is_customize_preview() ) {
		?>
		<div class="tapes-title window-color">
			<h3></h3>
			<div class="stripe-line"></div>
		</div>
		<?php
	}
}
?>

<?php if ( $wp_query->have_posts() ) : ?>
	<div class="post-section baghdad_news-template2">
	    <ul class="feature-posts-list">


			<?php
			while ( $wp_query->have_posts() ) :
				$wp_query->the_post();
				$choosed_color = array_rand( $colors, 1 );
				$category      = get_the_category();
				$postid        = get_the_ID();
				?>

                    <li class="feature-post">
						<div class="feature-post-img">

						    <a href="<?php echo esc_url( get_category_link( $category[0]->cat_ID ) ); ?>" class="category-block"
								title="<?php esc_html_e( 'Category', 'islemag' ); ?> <?php echo esc_attr( $category[0]->cat_name ); ?>">
								<?php echo esc_attr( $category[0]->cat_name ); ?>
							</a>
							
							<a href="<?php the_permalink(); ?>" title="<?php echo get_the_title(); ?>">
							    <?php echo covernews_post_format($post->ID); ?>
								<?php
								$thumb_id   = get_post_thumbnail_id( $postid );
								$thumb_meta = wp_get_attachment_metadata( $thumb_id );
								if ( ! empty( $thumb_id ) ) {
									if ( $thumb_meta['width'] / $thumb_meta['height'] > 1 || $thumb_meta['height'] / $thumb_meta['width'] > 1 ) {
										$thumb = the_post_thumbnail( 'baghdad_newss_small_thumbnail' );
									} else {
										$thumb = the_post_thumbnail( 'baghdad_newss_small_thumbnail_no_crop' );
									}
								} else {
									echo '<div class="no-featuer-img"><img src="' . esc_url( get_theme_mod('dosislite_nav_logo_url') ) . '" /></div>';
								}
								?>
							</a>
						</div> <!-- End .entry-media -->

						<div class="feature-post-title">
                            <a href="<?php the_permalink();?>">
                                <h4>
                                    <?php the_title();?>
                                </h4>
                            </a>
                        </div>

						<?php
						if ( function_exists( 'cwppos_calc_overall_rating' ) ) {
							$rating = cwppos_calc_overall_rating( $postid );
							if ( ! empty( $rating['option1'] ) ) {
								?>
								<label><?php esc_html_e( 'Rating:', 'baghdad_news' ); ?></label>
								<div class="star-ratings-css">
									<div class="star-ratings-css-top" style="width: <?php echo $rating['overall']; ?>%">
										<span><i class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span></div>
									<div class="star-ratings-css-bottom"><span><i class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span><span><i
													class="fa fa-star"></i></span></div>
								</div>
								<?php
							}
						}
						?>

						<div class="feature-post-inform">
                            <span class="post-author">
                                <span class="post-author"><i class="fa fa-pencil-square-o"></i><?php the_author_posts_link();?></span>
                                <span class="post-date"><i class="fa fa-clock-o"></i> <time datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished"><?php echo get_the_date(); ?></time> </span>
                                <a href="<?php the_permalink(); ?>#comments" title="<?php _e( 'Go to the post`s comments &raquo;', 'baghdad-news' ); ?>"><span class="meta-comment"><i class="fa fa-comments"></i><?php comments_number( '0', '1', '%' ); ?></span></a>
                            </span>
                        </div> <!-- End .entry-meta -->

						<!-- text -->
						<article class="feature-post-text ">
                            <?php the_excerpt();?>
                        </article>
					</li> <!-- End .entry-block -->
				<?php
			endwhile;
			?>


	    </ul>
	</div> <!-- End .post-section -->
<?php endif;
wp_reset_postdata(); ?>
