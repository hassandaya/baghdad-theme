<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

function baghdad_news_display_section( $section_nb, $is_hidden = false ) {
	$colors             = array( 'red', 'orange', 'blue', 'green', 'purple', 'pink', 'light_red' );
	$template           = 1;
	$baghdad_news_aria_label = '';
	switch ( $section_nb ) {
		case 1:
			$template              = $section_nb;
			$baghdad_news_title = get_theme_mod( 'baghdad_news1_title', esc_html__( 'Section 1', 'baghdad_news' ) );
			$baghdad_news_aria_label    = esc_html__( 'Ads Area 1', 'baghdad_news' );
			break;
		case 2:
			$template              = $section_nb;
			$baghdad_news_title = get_theme_mod( 'baghdad_news2_title', esc_html__( 'Section 2', 'baghdad_news' ) );
			$baghdad_news_aria_label    = esc_html__( 'Ads Area 2', 'baghdad_news' );
			break;
		case 3:
			$template              = 3;
			$baghdad_news_title = get_theme_mod( 'baghdad_news3_title', esc_html__( 'Section 3', 'baghdad_news' ) );
			$baghdad_news_aria_label    = esc_html__( 'Ads Area 3', 'baghdad_news' );
			break;
		case 4:
			$postperpage           = get_theme_mod( 'baghdad_news4_posts_per_page', 6 );
			$template              = 4;
			$baghdad_news_title = get_theme_mod( 'baghdad_news4_title', esc_html__( 'Section 4', 'baghdad_news' ) );
			$baghdad_news_aria_label    = esc_html__( 'Ads Area 4', 'baghdad_news' );
			break;
		case 5:
			$template              = 5;
			$baghdad_news_title = get_theme_mod( 'baghdad_news5_title', esc_html__( 'Section 5', 'baghdad_news' ) );
			$baghdad_news_aria_label    = esc_html__( 'Ads Area 5', 'baghdad_news' );
			break;
	}
	/*Do not delete these variables. Those are used in template files*/
	$baghdad_news_has_sidebar       = ( $section_nb === 1 ? is_active_sidebar( 'baghdad_news-ads' ) : is_active_sidebar( 'baghdad_news-ads-' . $section_nb ) );
	$baghdad_news           = get_theme_mod( 'baghdad_news' . $section_nb . '_fullwidth', false );
	$baghdad_news_category  = esc_attr( get_theme_mod( 'baghdad_news' . $section_nb . '_category', 'all' ) );
	$baghdad_news_max_posts = absint( get_theme_mod( 'baghdad_news' . $section_nb . '_max_posts', 6 ) );
	?>
	<div class="baghdad_news-section
	<?php
	echo $section_nb;
	if ( $is_hidden === true ) {
		echo ' baghdad_news_only_customizer ';}
	?>
	">
		<?php
		if ( $baghdad_news_has_sidebar ) {
			?>
			<div itemscope itemtype="http://schema.org/WPAdBlock" id="sidebar-ads-area-<?php echo $section_nb; ?>" aria-label="<?php echo $baghdad_news_aria_label; ?>">
				<?php ( $section_nb === 1 ? dynamic_sidebar( 'baghdad_news-ads' ) : dynamic_sidebar( 'baghdad_news-ads-' . $section_nb ) ); ?>
			</div>
			<?php
		}

		include( locate_template( 'template-parts/content-template' . $template . '.php' ) );
		?>
	</div>
	<?php
}