<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */


$wp_query = new WP_Query(
	array(
		'posts_per_page'      => $baghdad_news_max_posts,
		'order'               => 'DESC',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'category_name'       => ( $baghdad_news_category != 'all' ? $baghdad_news_category : '' ),
	)
);?>

<?php
	if ( ! empty( $baghdad_news_title ) ) {
?>
	<div class="tapes-title window-color">
		<h3><?php echo esc_attr( $baghdad_news_title ); ?></h3>
		<div class="stripe-line"></div>
	</div>
	<?php
} else {
	if ( is_customize_preview() ) {
	}
}
?>

<?php if ( $wp_query->have_posts() ) : ?>
	<div class="post-section baghdad_news-template2">
        <section class="slider-footer">
        <div class="slider">



			<?php
			while ( $wp_query->have_posts() ) :
				$wp_query->the_post();
				$choosed_color = array_rand( $colors, 1 );
				$category      = get_the_category();
				$postid        = get_the_ID();
				?>
                    <div class="slide active" style="background-image: url('<?php get_theme_mod( 'baghdad_news_nav_logo_url'); ?>')">
                        
                            
						        <div class="feature-post-img">
						        		<?php
						        		$thumb_id   = get_post_thumbnail_id( $postid );
						        		$thumb_meta = wp_get_attachment_metadata( $thumb_id );
						        		if ( ! empty( $thumb_id ) ) {
						        			if ( $thumb_meta['width'] / $thumb_meta['height'] > 1 || $thumb_meta['height'] / $thumb_meta['width'] > 1 ) {
						        				$thumb = the_post_thumbnail( 'baghdad_newss_small_thumbnail' );
						        			} else {
						        				$thumb = the_post_thumbnail( 'baghdad_newss_small_thumbnail_no_crop' );
						        			}
						        		} else {
						        			echo '<div class="no-featuer-img"><img src="' . esc_url( get_theme_mod('dosislite_nav_logo_url') ) . '" /></div>';
						        		}
						        		?>
								</div>
						<div class="container">
                            <div class="caption">
                            
                                <h1><a href="<?php the_permalink();?>">
                                    <?php the_title();?>
                                </a></h1>


								<div><?php the_excerpt();?></div>
								   
						    </div>
                        </div>
                    </div>
				<?php
			endwhile;
			?>
		</div>
		
         <!-- controls  -->
		<div class="controls">
            <div class="prev"><</div>
            <div class="next">></div>
        </div>
    
        <!-- indicators -->
         <div class="indicator">
		</div>
		
        </section>
	</div> <!-- End .post-section -->
<?php endif;
wp_reset_postdata(); ?>


