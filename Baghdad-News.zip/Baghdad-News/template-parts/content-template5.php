<?php
/**
 *
 * @since 1.0.0
 * 
 * @package baghdad_news
 */

$wp_query = new WP_Query(
	array(
		'posts_per_page'      => $baghdad_news_max_posts,
		'order'               => 'DESC',
		'post_status'         => 'publish',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'category_name'       => ( ! empty( $baghdad_news_category ) && $baghdad_news_category != 'all' ? $baghdad_news_category : '' ),
	)
);?>
<div class="ticker-news">
    <div class="ticker-cover">
<?php
	if ( ! empty( $baghdad_news_title ) ) {
?>
	<div class="ticker-title">
		<i class="fa fa-caret-right"></i>
        <strong><?php echo esc_attr( $baghdad_news_title ); ?></strong>
        <i class="fa fa-caret-left"></i>
	</div>
	<?php
} else {
	if ( is_customize_preview() ) {
		?>
		<div class="ticker-title">
	    	<i class="fa fa-caret-right"></i>
            <strong><i class="fa fa-newspaper"></i></strong>
            <i class="fa fa-caret-left"></i>
		</div>
		<?php
	}
}
?>
<div class="ticker-date">
    <marquee direction = "right" onmouseout="start ()" onmouseover="stop ()">
        <ul >
<?php if ( $wp_query->have_posts() ) : ?>
		<?php

		while ( $wp_query->have_posts() ) :
			$wp_query->the_post();

			$choosed_color = array_rand( $colors, 1 );
			$category      = get_the_category();
			$postid        = get_the_ID();
			?>

        
                <li>
                    <a href="<?php the_permalink(); ?>">
					<?php
									$thumb_id   = get_post_thumbnail_id( $postid );
									$thumb_meta = wp_get_attachment_metadata( $thumb_id );
									if ( ! empty( $thumb_id ) ) {
										if ( $thumb_meta['width'] / $thumb_meta['height'] > 1 || $thumb_meta['height'] / $thumb_meta['width'] > 1 ) {
											$thumb = the_post_thumbnail( 'baghdad_newss_small_thumbnail' );
										} else {
											$thumb = the_post_thumbnail( 'baghdad_newss_small_thumbnail_no_crop' );
										}
									} else {
										 echo '<div class="no-featuer-img"><img src="' . esc_url( get_theme_mod('dosislite_nav_logo_url') ) . '" /></div>';
									}
									?>
                        <?php the_title(); ?>
					</a>
				</li>
		       
			<?php
			endwhile;
		?> 
		</ul>
	</marquee>
</div>
  </div>
</div>
	<?php
	endif;
	wp_reset_postdata();
?>
