    
    
<?php
$baghdad_news_header_slider_category  = esc_attr( get_theme_mod( 'baghdad_news_header_slider_category', 'all' ) );
$baghdad_news_header_slider_max_posts = esc_attr( get_theme_mod( 'baghdad_news_header_slider_max_posts', '6' ) );
$baghdad_news3_fullwidth      = get_theme_mod( 'baghdad_news3_fullwidth', false );
$baghdad_news_header_slider_disable   = (bool) get_theme_mod( 'baghdad_news_header_slider_disable', false );
$baghdad_news_header_slider_random    = (bool) get_theme_mod( 'baghdad_news_header_slider_random', false );
$baghdad_news3_disable        = (bool) get_theme_mod( 'baghdad_news3_disable', false );
?>


    <!-- banner slider start -->
    <div class="body-container section-3">
        <div class="div-container div-division">
            <?php
                 $archive_content_classes = apply_filters( 'baghdad_news_archive_content_classes', array( 'baghdad_news-content-left', 'col-md-9' ) );
            ?>
    
            <?php                
             /* ---------Section 5--------- */
             if ( ! $baghdad_news3_fullwidth && ! $baghdad_news3_disable ) {
                 baghdad_news_display_section( 3 );
             }
            ?>
            </div>
        </div>
    </div>
    <!-- banner slider end   -->
    
    <!--footer .add3-start-->
    <div class="footer-before-add ">
        <div class="div-add3-division div-division">
        <?php
            $Advertisement_before_footer_url  =  get_theme_mod( 'baghdad_news_Advertisement_before_footer_url' );
	        $Advertisement_before_footer_img  =  get_theme_mod( 'baghdad_news_Advertisement_before_footer_img' );
	        $Advertisement_before_footer_code =  get_theme_mod( 'baghdad_news_Advertisement_before_footer_Code' );
        ?>

    
        <?php if ( ! empty( $Advertisement_before_footer_code ) ) { 
               echo  '<div class="Advertisement-article-footer adds">'.$Advertisement_before_footer_code.'</div>'; 
           
            }
            

            else {
                if ( ! empty( $Advertisement_before_footer_img ) ) {
                    echo '<div class="Advertisement-article-footer adds">
                              <a href="'.$Advertisement_before_footer_url.'" target="_blank">
                                  <img src="'.$Advertisement_before_footer_img.'" />
                              </a>
                          </div>';
                }
            }
            
            

        ?>
        </div>
    </div>
    <!--footer .add3-end..-->
	
	<!-- footer top social start-->
	<div class="social-container">
        <div class="social-container-division div-division">
            <!-- facebook -->
            <?php if(get_theme_mod('baghdad_news_facebook_url') ){ ?>
			    <a href="<?php echo esc_url( get_theme_mod('baghdad_news_facebook_url') ); ?> " title="<?php _e( 'Facebook', 'baghdad-news' ); ?>" target="_blank">
			    	<i class="fa fa-facebook"></i>
			    	<span><?php _e( 'Facebook', 'baghdad-news' ); ?></span>
                </a>
            <?php } ?>
            
            <!-- twitter -->
            
            <?php if(get_theme_mod('baghdad_news_twitter_url') ){ ?>
			    <a href="<?php echo esc_url( get_theme_mod('baghdad_news_twitter_url') ); ?>" title="<?php _e( 'Twitter', 'baghdad-news' ); ?>" target="_blank">
			    	
			    	<i class="fa fa-twitter tapes-color"></i>
			    	<span><?php _e( 'Twitter', 'baghdad-news' ); ?></span>
                </a>
            <?php } ?>
            
            <!-- instgarm -->

            <?php if(get_theme_mod('baghdad_news_instagram_url') ){ ?>
			    <a href="<?php echo esc_url( get_theme_mod('baghdad_news_instagram_url') ); ?>" title="<?php _e( 'instagram', 'baghdad-news' ); ?>" target="_blank">
			    	<i class="fa fa-instagram tapes-color"></i>
			    	<span><?php _e( 'instagram', 'baghdad-news' ); ?></span>
                </a>
            <?php } ?>

            
            <!-- youtube -->
            <?php if(get_theme_mod('baghdad_news_youtube_url') ){ ?>
			    <a href="<?php echo esc_url( get_theme_mod('baghdad_news_youtube_url') ); ?>" title="<?php _e( 'youtube', 'baghdad-news' ); ?>" target="_blank" >				
			    	<i class="fa fa-youtube tapes-color"></i>
			    	<span><?php _e( 'youtube', 'baghdad-news' ); ?></span>
                </a>
            <?php } ?>            
            
            <!-- mail -->
            
            <?php if(get_theme_mod('baghdad_news_mail_url') ){ ?>
			    <a href="mailto:<?php echo ( get_theme_mod('baghdad_news_mail_url') ); ?>" title="<?php _e( 'mail', 'baghdad-news' ); ?>" target="_blank">			
                    <i class="fa fa-envelope"></i>
			    	<span><?php _e( 'mail', 'baghdad-news' ); ?></span>
                </a>
            <?php } ?>


            <!-- ress -->
            <?php if(get_theme_mod('baghdad_news_rss_url') ){ ?>
			    <a href="<?php echo esc_url( get_theme_mod('baghdad_news_rss_url') ); ?>" title="Rss" target="_blank">				
			    	<i class="fa fa-rss tapes-color"></i>
			    	<span>rss feed</span>
                </a>
            <?php }  ?>
		</div>
	</div>
    <!-- footer top social end -->
    



    <!----footer-strat------->
    <footer class="footer-box">
        <div class="division-footer-box div-division">
              <div class="footer-container">
                   <div class="footer-column footer-column-1">
                        <?php if (is_active_sidebar('footer1')):?>
                            <?php dynamic_sidebar('footer1')?>
                        <?php endif; ?>
                   </div>

                   <div class="footer-column footer-column-2">
                        <?php if (is_active_sidebar('footer2')):?>
                            <?php dynamic_sidebar('footer2')?>
                        <?php endif; ?>
                   </div>


                   <?php $baghdad_news_Copyrights_text = get_theme_mod( 'baghdad_news_Copyrights_text',esc_html__( 'Copyright © All rights reserved | Baghdad News Theme.', 'baghdad-news' ) ); ?>
                   <?php if ( ! empty( $baghdad_news_Copyrights_text ) ) { ?>
                        <div class="footer-column-Copyrights Copyrights">
                           <p><?php echo esc_attr( $baghdad_news_Copyrights_text ); ?></p>
                       </div>
                       
                    <?php } else {
	                    if ( is_customize_preview() ) {
                    	}
                    }?>
                   
              </div>
		</div>
    </footer>
                            
    
    <!----footer-end..------->






	<!-- search form start -->
	<div class="top-search-form">
        <form role="search" method="get" id="searchform" action="<?php echo get_home_url(); ?>">
			<input class="search-in"type="text" placeholder="<?php esc_html_e( 'write here', 'baghdad-news' ); ?>"  name="s" di="s" id="search" value="<?php the_search_query(); ?>">
			<input class="search-bo"type="submit" id="searchsubmit" value="<?php esc_html_e( 'search', 'baghdad-news' ); ?>">
			
			<a class="close-search-form-top">
		        <i class="fa fa-times"></i>
			</a>
			
	    </form>
		
	</div>	
				
    <!-- search form end -->
    
    <!-- pages icon start -->
    <span class="go-up-2" id="go-up-2" title="<?php _e( 'Go to the top', 'baghdad-news' ); ?>">
	    <i class="fa fa-arrow-up"></i>
	</span>
    <!-- pages icon end   -->
    
    <style>
        @media   (max-width:500px){
            .go-up-2 ,.go-up-active{
        display: none;
        visibility: hidden;
        position: fixed;
        top: -20%;left: -20%;
    }
        }
    </style>

</body>

<script src="http://code.jquery.com/jquery-3.4.1.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php wp_footer();?>
</html>