<?php $baghdad_news_Mobile_Menu_bg_img = get_theme_mod( 'baghdad_news_Mobile_Menu_bg_img');
	  $baghdad_news_nav_logo_url       = get_theme_mod( 'baghdad_news_nav_logo_url'); 
	  $main_logo                       = get_custom_logo('small');?>
<!DOCTYPE html>
<html>
<head>
    
	<title><?php bloginfo('name');?></title>
	<meta content='width=device-width, initial-scale=1' name='viewport'/>
	 <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
	rel="stylesheet" >	

    <STYle>
	    html{
			--header-cover-color:var(--cover-color);
            --back-color:#e9f5fc;
            --tapes-color:#ff8500;
			--window-color:#ffffff;
			--cover-color:#e9f5fc;
			--info-color:#8c867f;
            --top-nav-color:#ffffff;
			--normal-text-color:#3b3f3f;
			--mobile-header-bg:#ffffff;
			--mobile-main-aree-bg:var(--cover-color);
			--mobile-icon-menu-bg:var(--cover-color);
			--mobile-icon-menu-color:var(--text-link-colo);
			--footer-bg:#333;
			--footer-title-color:#adacac;
			--footer-link-color:#fff;
			--footer-text-color:var(--info-color);
			--Copyrights-background:#587897;
			--Copyrights-color:#fff;
            --search-back-c:#7b7b7b8c;
			--text-link-colo:#587897;
			--img-outline-color:#587897;
            --shadow-color:#aaa5a5;
            --nav-top-bg:-webkit-linear-gradient(0deg,#111111 0%, #222222 100%);
            --bor-min-nav:rgba(74,74,74,0.05);
            --bor-min-nav-bootom:2px 3.464px 9px 0 rgba(145, 17, 17, 0.062);
            --img-shading-colo:none;
            --main-nav-bg:#fff;
            --top-bar-a-opacity:0.5;
            --top-bar-a-opacity-hover:1;
			transition: all 0.2s ease-in-out;margin: 0;
			--lwp-back-img:url(photo/body-bg.png);
			--Mobile-Menu-color:#9e9e9e;
        }

        .html-dark{
			--header-cover-color:var(--cover-color);
            --back-color: #262626;
			--window-color: #262626;
			--cover-color:#2d2d2d;
			--normal-text-color:#8c867f;
			--mobile-header-bg:#252525;
			--mobile-main-aree-bg:var(--cover-color);
			--mobile-icon-menu-bg:var(--cover-color);
			--mobile-icon-menu-color:var(--text-link-colo);
            --text-link-colo:#ececec;
            --search-back-c:rgba(0, 0, 0, 0.8);
            --shadow-color:#9c999947;
            --nav-top-bg:-webkit-linear-gradient(0deg,#000000 0%, #000000 100%);
            --bor-min-nav:rgba(53, 53, 53, 0.36);
            --bor-min-nav-bootom:2px 3.464px 9px 0 rgba(145, 17, 17, 0.19);
            --img-shading-colo: rgba(00,00,00,0.2);
            --main-nav-bg:##16141b;
		}
         
		.main-aree-2 .main-aree-backcolor{
		    background-image: url(<?php echo esc_url($baghdad_news_Mobile_Menu_bg_img); ?>);
		    background-size: cover;
            background-position: center center;
		}
		
		body .adds::before{
            content:"<?php echo _e('Advertising') ?>";
		}
	</STYle>

    <?php wp_head();?>

</head>







<body <?php body_class(); ?> onload="myFunction()">



<!-- web loading start -->
<!-- one intro start -->
<div id="intro" class="intro">
    <div class="one one-intro">
        <div class="logo">
		    <?php if ( ! empty( $baghdad_news_nav_logo_url ) ) { ?>
					<img src="<?php echo esc_url( $baghdad_news_nav_logo_url ); ?>" alt="<?php bloginfo( 'name' ); ?>" />
                <?php } else {
	               if ( is_customize_preview() ) {
                }
            }?>
           <div class="intro-loading">
            <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
           </div>
        </div>

        <div class="social-icons-intro">
		    <h2> <?php bloginfo('name');?></h2> <br/>
            <li class="intro-sohial-icone">
                <i class="fa fa-facebook"></i>
            </li>

            <li class="intro-sohial-icone">
                 <i class="fa fa-twitter tapes-color"></i>
            </li>

        

            <li class="intro-sohial-icone">
                <i class="fa fa-instagram tapes-color"></i>
            </li>
        
            <li class="intro-sohial-icone">				
                <i class="fa fa-youtube tapes-color"></i>
            </li>
        
        
            <li class="intro-sohial-icone">				
                <i class="fa fa-rss tapes-color"></i>
            </li>        
        </div>
    </div>
<!-- one intro enddd -->
<!-- tow intro start -->

    <div class="one tow-intro">
        <div class="tow tow-one">
            <div class="tow">
                <div class="tow">
                    <div class="tow">
                        <div class="tow">
                        </div>  
                    </div>  
                </div>  
            </div>            
        </div>
    </div>
</div>
<!-- tow intro endd -->
<!-- web loading ind -->

<?php
/**
 * WordPress function to load custom scripts after body.
 *
 * Introduced in WordPress 5.2.0
 *
 * @since ColorMag 1.4.0
 */
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
?>
<div class="background-cover ">


	<!-----header-start---->
	<div class="header-cover">
	<header class="header-body">  <!------ok----->
       
		<!-------header-div.start---->
		<div class="div-top-nav">  <!------ok----->                     
			<div id="div2-top-nav" class="div-division">   <!------ok----->
				<!------header-search-li.start---->
				<span class="search-icon " id="click-search-top">
					<span href="#"  class="search-icon-1  tapes-color hover-colo" >
						<i class="fa fa-search" aria-hidden="true"></i>
					</span>
				</span>


				 

				
				


				<!-- search form start -->
				<div class="top-search-form-2">
				<form role="search" method="get" id="searchform" action="<?php echo get_home_url(); ?>">
						<input class="search-in"type="text" placeholder="<?php esc_html_e( 'write here', 'baghdad-news' ); ?>"  name="s" di="s" id="search" value="<?php the_search_query(); ?>">
						<input class="search-bo-2"type="submit" id="searchsubmit" value="<?php esc_html_e( 'search', 'baghdad-news' ); ?>">
						
						<a class="close-search-form-top">
					        <i class="fa fa-times"></i>
						</a>
						
				    </form>
					
				</div>
				
				
				<!-- search form end -->

				<!-------header-search-li.end..---->

                <span class="head-top-menu ">

					
					<?php

						wp_nav_menu( array(
							'theme_location' => 'header',
                            'container'         => 'span',
							'menu'            => '',
							'container_class' => '',
							'container_id'    => '',
							'menu_class'      => 'nav top-nav',
							'menu_id'         => '',
							'echo'            => true,
							'fallback_cb'     => 'wp_page_menu',
							'before'          => '',
							'after'           => '',
							'link_before'     => '',
							'link_after'      => '',
							'items_wrap'      => '<ul id="%1$s" class="hassan">%3$s</ul>',
							'item_spacing'    => 'preserve',
							'depth'           => 0,
							'walker'          => '',
                        ) );
                    ?>

				</span>
				
						
				
				<!-- dark mode switch end -->
				<div class="switcher">
					<span class="switcher_wrap">
						<i class="fa fa-sun-o fa-lg" aria-hidden="true"></i>
						<i class="fa fa-moon-o fa-lg" aria-hidden="true"></i>
					</span>
				</div>


				<!-- social top nav icons  -->
				<div class="social-icons-top">
                    <!-- facebook -->
                    <?php if(get_theme_mod('baghdad_news_facebook_url') ){ ?>
		        	    <a href="<?php echo esc_url( get_theme_mod('baghdad_news_facebook_url') ); ?> " title="Facebook" target="_blank">
		        	    	<i class="fa fa-facebook"></i>
                        </a>
                    <?php } ?>

                    <!-- twitter -->
            
                    <?php if(get_theme_mod('baghdad_news_twitter_url') ){ ?>
		        	    <a href="<?php echo esc_url( get_theme_mod('baghdad_news_twitter_url') ); ?>" title="Twitter" target="_blank">
		        	    	
		        	    	<i class="fa fa-twitter tapes-color"></i>
                        </a>
                    <?php } ?>
            
					

                    <!-- instgarm -->

                    <?php if(get_theme_mod('baghdad_news_instagram_url') ){ ?>
			            <a href="<?php echo esc_url( get_theme_mod('baghdad_news_instagram_url') ); ?>" title="instagram" target="_blank">
			            	<i class="fa fa-instagram tapes-color"></i>
                        </a>
                    <?php } ?>        
					
					                   
                    <!-- youtube -->
                    <?php if(get_theme_mod('baghdad_news_youtube_url') ){ ?>
			            <a href="<?php echo esc_url( get_theme_mod('baghdad_news_youtube_url') ); ?>" title="youtube" target="_blank" >				
			            	<i class="fa fa-youtube tapes-color"></i>
                        </a>
                    <?php } ?>
					
					
					<?php if(get_theme_mod('baghdad_news_rss_url') ){ ?>
			            <a href="<?php echo esc_url( get_theme_mod('baghdad_news_rss_url') ); ?>" title="Rss" target="_blank">				
			            	<i class="fa fa-rss tapes-color"></i>
                        </a>
                    <?php } ?>

					
				</div>
			</div>
		</div>
		<!-------header-div.end------->

        <style>
        @media (min-width:1100px) {

			.logo-head-1{
				transition: background .1s;
			}
			
			.wide .logo-head-1{
                background: var(--header-cover-color);
				background-image:url(<?php header_image(); ?>);
                background-position: center;
				background-size: contain;
			} 
			

			.boxes .logo-head-2{
                background: var(--header-cover-color);
                background-image:url(<?php header_image(); ?>);
                background-position: center;
                background-size: contain;
			 }
		}
		</style>

	    <!-------header-logo.start----->
	    <span class="logo-head-1 " >  <!------ok----->
            <div class="logo-head-2 div-division"> <!------ok----->
				<?php if ( ! empty( $main_logo ) ) {
					 echo $main_logo ;
				}else {
					
						echo '<div class="wp-name">
									<a  href="'.get_home_url().'">
										<h1 class="web-title">'.get_bloginfo('name').'</h1>
									</a>
							  </div>';
					
				}?>	     	    
            </div>
	    </span>
	     <!-------header-logo.end..----->
        <!-- nav main menu start -->
		<nav class="main-aree-2">
			<div class="main-aree-backcolor">

			    <?php if ( ! empty( $baghdad_news_nav_logo_url ) ) { ?>
					<div class="nav-img-logo">
						<img src="<?php echo esc_url( $baghdad_news_nav_logo_url ); ?>" alt="<?php bloginfo( 'name' ); ?>" />
					</div>
                    <?php } else {
	                   if ( is_customize_preview() ) {
                    }
                }?>

 
				<!-- nav main menu end  -->
                <?php
					   	wp_nav_menu( array(
						'theme_location' => 'main-menu',
                      'container'    => 'span',
						'menu'            => '',
						'container_class' => 'hassan',
						'container_id'    => '',
						'menu_class'      => 'nav main-nav',
					'menu_id'         => '',
					'echo'            => true,
					'fallback_cb'     => 'wp_page_menu',
					'before'          => '',
					'after'           => '',
						'link_before'     => '',
					'link_after'      => '',
					'items_wrap'      => '<ul id="%1$s" class="main-nav nav-menu">%3$s</ul>',
						'item_spacing'    => 'preserve',
						'depth'           => 0,
						'walker'          => '',
                    ) );
				?>


                <div class="menu-social">
                    <ul class="enu-social-list">
						<?php if(get_theme_mod('baghdad_news_facebook_url') ){ ?>
							<li>
                            <!-- facebook -->
                                <a class="facebook" href="<?php echo esc_url( get_theme_mod('baghdad_news_facebook_url') ); ?> " title="Facebook" target="_blank">
                                    <i class="fa fa-facebook"></i>
							    </a>
						    </li>
						<?php } ?>
							
						<?php if(get_theme_mod('baghdad_news_twitter_url') ){ ?>
							<li>
                               <!-- ---twitter-- -->
                                 <a class="twitter "  href="<?php echo esc_url( get_theme_mod('baghdad_news_twitter_url') ); ?>" title="Twitter" target="_blank">
                                    <i class="fa fa-twitter"></i>
							    </a>
						    </li>
						<?php } ?>

						<?php if(get_theme_mod('baghdad_news_instagram_url') ){ ?>
							<li>
			                    <a class="instgram" href="<?php echo esc_url( get_theme_mod('baghdad_news_instagram_url') ); ?>" title="instagram" target="_blank">
			                	    <i class="fa fa-instagram tapes-color"></i>
							    </a>
						    </li>
						<?php } ?>
						
						<!-- youtube -->
						<?php if(get_theme_mod('baghdad_news_youtube_url') ){ ?>
							<li>
			                    <a class="youtube" href="<?php echo esc_url( get_theme_mod('baghdad_news_youtube_url') ); ?>" title="youtube" target="_blank" >				
			                	    <i class="fa fa-youtube tapes-color"></i>
							    </a>
						    </li>
                        <?php } ?> 

						<?php if(get_theme_mod('baghdad_news_mail_url') ){ ?>
							<li>
                            <!-- ---email-- -->
                                <a class="mail" href="mailto:<?php echo ( get_theme_mod('baghdad_news_mail_url') ); ?>" title="Mail" target="_blank">
                                    <i class="fa fa-envelope"></i>
							    </a>
						    </li>
						<?php } ?>
							

                    </ul>
                </div>
			</div>
		</nav>
		<!-- random nav start -->

		<!-------header-nav.start----->
		<div class="main-menu-body">
	       <nav  class="nav-main-menu main-menu-position menu-main" >   <!------ok----->
				<div class="div-nav-main-menu div-division">    <!------ok----->
					<?php if ( ! empty( $baghdad_news_nav_logo_url ) ) { ?>
					<a href="<?php echo get_home_url(); ?>"><span class="main-menu-logo ">						
                           <img src="<?php echo esc_url( $baghdad_news_nav_logo_url ); ?>" alt="<?php bloginfo( 'name' ); ?>" />
				    </a></span>
					<?php } else {
	                    if ( is_customize_preview() ) {
                    	}
                    }?>

                    <!-------home/icon-start----->
                    <span class="homeicon ">  <!------ok----->
                        <a href="<?php echo get_home_url(); ?>" >    <!------ok----->
                            <i class="fa fa-home" aria-hidden="true"></i>
						</a>
						
					</span>
					

					<!-------home/icon-end..----->

					<!-- go up start -->
					<span class="go-up" id="go-up" title="<?php _e( 'Go to the top', 'baghdad-news' ); ?>">
						<i class="fa fa-arrow-up"></i>
					</span>
					<!-- go up end   -->

					<!-- list menu icom strat -->

                    <div class="list-icon-main-menu ">
                    	<div class="list-border list-border-1"></div>
                    	<div class="list-border list-border-2"></div>
                    	<div class="list-border list-border-3"></div>
                    </div>
					
				   <!-- list menu icon end -->
					   


					

                    <!-- nav main menu start -->
                    <nav class="main-aree">
					 <div class="main-aree-backcolor">

					 
 
					   <!-- nav main menu end  -->
                       <?php
   
					   	wp_nav_menu( array(
					   		'theme_location' => 'main-menu',
                            'container'    => 'span',
					   		'menu'            => '',
					   		'container_class' => 'hassan',
					   		'container_id'    => '',
					   		'menu_class'      => 'nav main-nav',
					   		'menu_id'         => '',
					   		'echo'            => true,
					   		'fallback_cb'     => 'wp_page_menu',
					   		'before'          => '',
					   		'after'           => '',
					   		'link_before'     => '',
					   		'link_after'      => '',
					   		'items_wrap'      => '<ul id="%1$s" class="main-nav nav-menu">%3$s</ul>',
					   		'item_spacing'    => 'preserve',
					   		'depth'           => 0,
					   		'walker'          => '',
                           ) );
					   ?>


					 </div>
					</nav>
					<!-- nav main menu endd -->

					<!-- random nav start -->
					<?php
                        $args = array('posts_per_page'      => 1,
                                      'orderby' => 'rand' ,
                                     );
                        $rand_posts = get_posts( $args );
                        foreach( $rand_posts as $post ) : ?>
						
					        <span class="random" title="مقال عشوائي">
                                <a href="<?php the_permalink(); ?>">
					        		<i class="fa fa-random"></i>
					        	</a>
					        </span>
					    <?php endforeach; 
					?>

					<!-- random nav end -->
				   
                </div>		
		    </nav>
	    </div>
		
		
	    <!-------header-nav.end..----->


	</header>
    </div>
    <!-----header-end..---->

    <!------div.body-start------>
    <div class="body-container ">  <!------ok----->