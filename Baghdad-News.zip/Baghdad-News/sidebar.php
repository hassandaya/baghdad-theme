    <!-----aside-start-------->
    <aside id="side" class="aside-box sidebar-wrapper">
        <div class="div-aside-box theiaStickySidebar">
    
            <article id="sticky-sidebar" class="aside-article">
    
                <?php if (is_active_sidebar('sidebar')):?>
                    <?php dynamic_sidebar('sidebar')?>
                <?php endif; ?>
            </article>
            <!-----------------> 
        </div>
    </aside>
    </div></div>
   <!-----aside-end..-------->
   
</div>
<!-------div.body-end..------->