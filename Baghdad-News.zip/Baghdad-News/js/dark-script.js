
            // check for saved 'html-dark' in localStorage
            // let darkMode = localStorage.getItem('html-dark'); 

            let darkMode = localStorage.getItem('html-dark'); 

            const darkModeToggle = document.querySelector('.switcher');

            const enableDarkMode = () => {
              // 1. Add the class to the body
              document.body.classList.add('html-dark');
              // 2. Update darkMode in localStorage
              localStorage.setItem('html-dark', 'enabled');
            }

            const disableDarkMode = () => {
              // 1. Remove the class from the body
              document.body.classList.remove('html-dark');
              // 2. Update darkMode in localStorage 
              localStorage.setItem('html-dark', null);
            }
 
            // If the user already visited and enabled darkMode
            // start things off with it on
            if (darkMode === 'enabled') {
              enableDarkMode();
            }

            // When someone clicks the button
            darkModeToggle.addEventListener('click', () => {
              // get their darkMode setting
              darkMode = localStorage.getItem('html-dark'); 
              
              // if it not current enabled, enable it
              if (darkMode !== 'enabled') {
                enableDarkMode();
              // if it has been enabled, turn it off  
              } else {  
                disableDarkMode(); 
              }
            });





            