 //  top search icon scripting

 $(document).ready(function(){
    $('#click-search-top').click(function(){
        $('.head-top-menu ').addClass('head-top-menu-click')
        $('.top-search-form ').addClass('top-search-form-active')
        $('.search-icon').addClass('search-icon-active')
        $('.background-cover ').addClass('background-cover-search-active')
    })

        $('.body-container, .logo-head-1 , .main-menu-body , .close-search-form-top').click(function(){
            $('.top-search-form ').removeClass('top-search-form-active')
            $('.search-icon ').removeClass('search-icon-active')
            $('.background-cover ').removeClass('background-cover-search-active')
        })
    

})

// nav main menu fixed scripting



$(window).scroll(function(){
    if($(this).scrollTop()>190){
        $('.menu-main').addClass("sticky");
        $('.main-menu-logo').addClass("main-menu-logo-fixed");
        $('.homeicon').addClass("homeicon-fixed");
        $('.go-up-2').addClass("go-up-active");
    }
    else{
        $('.menu-main').removeClass("sticky");
        $('.main-menu-logo').removeClass("main-menu-logo-fixed");
        $('.homeicon').removeClass("homeicon-fixed");
        $('.go-up-2').removeClass("go-up-active");
    }
})

$(window).scroll(function(){
    if($(this).scrollTop()>90){
        $('.header-body').addClass("header-body-active");
    }
    else{
        $('.header-body').removeClass("header-body-active");
    }
})


// window.addEventListener("scroll", function(){
//     var header = document.querySelector(".header-body")
//     header.classList.toggle("header-body-active", window.scrollY > 0)
// })



// nav menu to mobile screen 

$(document).ready(function(){
    $('.list-icon-main-menu').click(function(){
        $('.main-aree-2').toggleClass('main-aree-active-2')
        $('body').toggleClass('body-over')
        $('.list-icon-main-menu').toggleClass('list-menu-active')
        $('.head-top-menu').toggleClass('head-top-menu-clicker')
        $('.list-icon-main-menu').toggleClass('list-icon-main-menu-act')
    })
})

// nav menu nav menu

$(document).ready(function(){
    $(".nav-main-menu").hover(function(){
        $('body').toggleClass('body-before')
        $('.nav-main-menu').toggleClass('menu-hover')
    })
})

