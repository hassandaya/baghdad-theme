// post single img

 $(document).ready(function(){
     $(".post-sigle-img").click(function(){
        $('.separator').toggleClass('separator-close')
        $('body').toggleClass('body-over')
    })
});

$('#go-up').click(function(){
    $('html').animate({scrollTop: 0}, "slow");
});
$('#go-up-2').click(function(){
    $('html').animate({scrollTop: 0}, "slow");
});


// Loading Screen
var preloader = document.getElementById('intro');
function myFunction(){
    preloader.style.opacity = '0'
    preloader.style.display = 'none';
}


// widget slider
function resetTimer(){
    clearInterval(timer);timer=setInterval(autoPlay,4000);
}
function autoPlay(){
    nextSlide();updateCircleIndicator();
}
let timer=setInterval(autoPlay,4000);
var slideIndex=0;carousel();
function carousel(){
    var i;var x=document.getElementsByClassName("mySlides");
    for(i=0;i<x.length;i++){x[i].style.display="none";
}
slideIndex++;if(slideIndex>x.length){slideIndex=1}
x[slideIndex-1].style.display="block";setTimeout(carousel,6000);}



var slideIndex = 1;
   showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
    var i;
    var x = document.getElementsByClassName("mySlides");
    if (n > x.length) {slideIndex = 1}
    if (n < 1) {slideIndex = x.length} ;
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
    }
    x[slideIndex-1].style.display = "block";
  }






