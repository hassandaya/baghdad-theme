<?php get_header();?>
<?php
$baghdad_news_header_slider_category  = esc_attr( get_theme_mod( 'baghdad_news_header_slider_category', 'all' ) );
$baghdad_news_header_slider_max_posts = esc_attr( get_theme_mod( 'baghdad_news_header_slider_max_posts', '6' ) );
$baghdad_news5_fullwidth      = get_theme_mod( 'baghdad_news5_fullwidth', false );
$baghdad_news_header_slider_disable   = (bool) get_theme_mod( 'baghdad_news_header_slider_disable', false );
$baghdad_news_header_slider_random    = (bool) get_theme_mod( 'baghdad_news_header_slider_random', false );
$baghdad_news5_disable        = (bool) get_theme_mod( 'baghdad_news5_disable', false );
?>
     <div class="div-container div-division"> <!------ok----->
     <style>
@media (max-width: 500px){
    .header-cover{
        height:50px;
        margin-bottom:10px;
    }
    .header-body {
        position: fixed;
        top: 0;
        height: 42px;
        padding-bottom: 10px;
        padding: 2px 2%;
        transition: .1s;
        z-index: 99;
    }
    .header-body .social-icons-top {
       opacity: 0;
       visibility: hidden;
    }
}
</style>
        <!-- news ticker start -->
        <div class="news-ticker-bar">
           
           <?php
                $archive_content_classes = apply_filters( 'baghdad_news_archive_content_classes', array( 'baghdad_news-content-left', 'col-md-9' ) );
           ?>
   
          <?php                
            /* ---------Section 5--------- */
            if ( ! $baghdad_news5_fullwidth && ! $baghdad_news5_disable ) {
                baghdad_news_display_section( 5 );
            }
           ?>
        </div>
        <!-- news ticker end   -->
         <!----div.post-start--------->
        <div class="div-content ">
         <div class="content-treexil ">


            <?php if (have_posts()):?>
                <?php while (have_posts()):?>
                    <?php the_post();?>
                    <!--------post single box code start--------->
                    <div id="side" class="post-side content sidebar-wrapper">
                        
			        <section class="bost-box-single">

                        <div itemprop="blogPost" itemscope="itemscope" itemtype="http://schema.org/BlogPosting">
                            <div class="post-header">

                                <div class="post-head">
                                     <h1 class="post-title entry-title" itemprop="name headline">
                                       <?php the_title();?>
                                     </h1>
                                </div>

                                <div class="post-meta">
                                    <span class="post-author vcard">
                                        <i class="fa fa-user"></i>
                                        <span class="fn" itemprop="author" itemscope="itemscope" itemtype="http://schema.org/Person">
                                                <span itemprop="name"><?php the_author_posts_link();?></span>
                                        </span>
                                    </span>
                                    <span class="post-timestamp">
                                        <i class="fa fa-clock-o"></i>
                                         <time datetime="<?php echo get_the_date('c'); ?>" itemprop="datePublished"><?php echo get_the_date(); ?></time>
                                    </span>
                                </div>
                            </div>
                            
                            <article class="item-article">
                                <div class="post-body entry-content" id="post-body-1437166064562756638" itemprop="articleBody">
                                    <div dir="rtl" style="text-align: right; padding-bottom: 10px;" trbidi="on">
                                        <div dir="rtl" class="post-sigle-img" style="text-align: right;" trbidi="on">
                                            <div class="separator" style="clear: both; text-align: center;">
                                                <?php the_post_thumbnail( 'full');?>
                                            </div>
                                        </div>
					        		</div>
							
						        	<div class="bost-box-text-singl ">
						        		<?php the_content();?>
						        	</div>
                                </div>
                            </article>
                        </div>
    	            </section>
                </div>
                    <!--------post single box code end --------->
                <?php endwhile; ?>
                <?php else: ?>
                <div class="main-content tie-col-md-8 tie-col-xs-12" role="main">

		
                    <header class="entry-header-outer container-wrapper">
                    	<h1 class="page-title">لم يتم العثور على نتائج</h1>
                    </header><!-- .entry-header-outer /-->

                    <div class="mag-box not-found">
                    	<div class="container-wrapper">
                    
                    		
                    			<h5>يبدوا أننا لم ’ نستطيع أن نجد المحتوى ’الذي تبحث عنه. من الممكن أن البحث يفيدك.</h5>
                                <form role="search" method="get" id="searchform" class="search-form" action="<?php echo get_home_url(); ?>">                  
                    		        <label>
                                        <input class="search-field"type="text" placeholder="search form"  name="s" di="s" id="search" value="<?php the_search_query(); ?>">
                                    </label>
                            
                                    <input class="search-submit" type="submit" id="searchsubmit" value="بحث">
                            	</form>
                    		
                    	</div><!-- .container-wrapper /-->
                    </div><!-- .mag-box /-->

	            </div>
            <?php endif;?>

         </div>
        </div>
        <!----div-end..--------->

<?php get_sidebar();?>
<?php get_footer();?>